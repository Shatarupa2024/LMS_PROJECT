<html>
<head>
  <link rel="stylesheet" href="homepageStyles1.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<body>

  <center>
    <h1 style="font-family: georgia; font-size: 30px; font-weight: bold; color: #09080f;"><u><i> Online Library Management System </i></u></h1>
  </center> 
  <hr>

<div class="marq">
  <marquee behavior="alternate" direction="right">Bijoy Krishna Girls' College , Howrah
  <br>
  &nbsp; &nbsp; &nbsp;Computer Science Department</marquee>
</div>
  <hr>

  <ul>
    <a href="homePage.php"><i class="fa fa-home fa-2x" style="color: black; margin-top:9px;"></i></a>
    <li><a href="terms&conditions.php"><i> Student Register </i></a></li>
    <li><a href="studentLogin_sa.php"><i> Student Login </i></a></li>
    <li><a href="adminRegistration_sa.php"><i> Admin Register </i></a></li>
    <li><a href="adminLogin_sa.php"><i> Admin Login </i></a></li>
  </ul>

</body>
</html>



<!-- PHP code for connection -->
<?php
session_start();

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lmsdb";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for auto increment the isbn no -->

<?php
  $query = "SELECT * FROM admin_table ORDER BY ADMIN_ID DESC LIMIT 1";
    $result = mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result);
  @$last_admin_id = $row['ADMIN_ID'];
  if ($last_admin_id == "") {
    $admin_id = "AD01";
  }
  else {
    $num = substr($last_admin_id, 2); //then num = 0001
    $digit = intval($num); //convert string 0001 to integer
    $digit = $digit + 1; // 0001 + 1 = 2 but want 0002 so,
    $get_string = str_pad($digit, 2, 0, STR_PAD_LEFT); // get 0002 as string type 
    $admin_id = "AD" . $get_string;
  }
?>


<!-- PHP code for insert data in table  -->
<?php

  if(isset($_POST['login'])) {

      $conn = mysqli_connect($servername, $username, $password, $dbname);
      if($_SERVER["REQUEST_METHOD"] == "POST"){
      
        @$admin_id = $_POST['admin_id'];

        @$n = $_POST['fname'].' '.$_POST['lname'];
        @$name = strtoupper($n);
        @$admin_name = $name;
        
        @$email = $_POST['email'];
        @$phone = $_POST['phnumber'];
        @$password = $_POST['password'];
        @$joining_date = $_POST["joining_date"];
        @$modification_date = $_POST["joining_date"];
        @$status = "Active";


          $query = "SELECT * FROM admin_table WHERE ADMIN_ID = '$admin_id' && ADMIN_PASSWORD = '$password'";
          $result = mysqli_query($conn, $query);

          $row = mysqli_fetch_array($result , MYSQLI_ASSOC);

          $count = mysqli_num_rows($result);

          if($count == 1){
            echo '<script> alert("Login Sucessfull.."); </script>';
            echo '<script>window.location = "admin/welcomeAdminPage.php";</script>';
            
            $admin_id = $row['ADMIN_ID'];
            $_SESSION['adminId'] = $admin_id;

            $admin_name = $row['ADMIN_NAME'];
            $_SESSION['adminName'] = $admin_name;

            $email = $row['ADMIN_EMAIL_ID'];
            $_SESSION['adminEmail'] = $email;

            $phone = $row['ADMIN_MOBILE_NO'];
            $_SESSION['adminPh'] = $phone;

            $password = $row['ADMIN_PASSWORD'];
            $_SESSION['adminPasswd'] = $password;

            //header("location:admin/welcomeAdminPage.php");
          }
          else{
            echo '<script> alert("Login failed...Invalid username or password..."); </script>';
            echo '<script>window.location = "adminLogin_sa.php";</script>';
          }

          /*Close the connection.*/
          mysqli_close($conn);
      }
  }

?>


<html>
<head>
<title>Admin Login Page</title>
<link rel="stylesheet" href="adminStudentLoginStyle_sa.css">
</head>
<body>
<div class="main">
    <form method="post">
    
    <div class="imgcontainer">
      <img src="avatar.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b>Admin Id : </b></label><br>
      <input type="text" name="admin_id" id="id" placeholder="Enter your id" required><br>

      <label><b>Password : </b></label><br>
      <input type="password" placeholder="Enter your Password" name="password" id='password' required><br>

      <button type="submit" name="login"><b> Login </b></button>
    </div>

    <button type="button" class="cancelbtn"><a href="homePage.php"> Cancel </a></button>

      <span class="psw"><a href="adminForgotPassword_sa.php"><b> Forgot Password ? </b></a></span>

      <span class="psw"> Not register yet ? <a href="adminRegistration_sa.php"><b> Register here </b></a></span>
      
    </form>
</div>
</body>
</html>