<?php 

//connecting to the database
$host = "localhost";
$username = "root";
$password = "";

//create a connection
$conn = mysqli_connect($host, $username, $password);

//die if connection was not successfull
if(!$conn) {
	die("Failed to connect.".mysqli_connect_error());
}
else {
	echo "Connected successfully<br>";
}

//create a database
$query = "CREATE DATABASE IF NOT EXISTS lmsdb";
$res = mysqli_query($conn, $query);

//check for the database creation success or not
if($res) {
	echo "The database created successfully.<br>";
}
else {
	echo "The database not created successfully beacause of the error...",mysqli_error($conn);
}

?>