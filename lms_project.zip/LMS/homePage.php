<html>
<head>
	<link rel="stylesheet" href="homepageStyles1.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

	<center>
		<h1 style="font-family: georgia; font-size: 30px; font-weight: bold; color: darkblue;"><u><i> Online Library Management System </i></u></h1>
	</center> 
	<hr>

<div class="marq">
	<marquee behavior="alternate" direction="right"><i> Bijoy Krishna Girls' College , Howrah</i>
	<br>
	&nbsp; &nbsp; &nbsp;<i> Computer Science Department </i></marquee>
</div>
  <hr>

	<ul>
		<a href="homePage.php"><i class="fa fa-home fa-2x" style="color: black; margin-top:9px;"></i></a>
		<li><a href="terms&conditions.php"><i> Student Register </i></a></li>
		<li><a href="studentLogin_sa.php"><i> Student Login </i></a></li>
		<li><a href="adminRegistration_sa.php"><i> Admin Register </i></a></li>
		<li><a href="adminLogin_sa.php"><i> Admin Login </i></a></li>
	</ul>
	<br>

<div class="slideshow-container">

	<div class="mySlides fade">
	  <div class="numbertext">1 / 3</div>
	  <img src="firstpage1.jfif" style="width:1000px; height: 360px;">
	</div>

	<div class="mySlides fade">
	  <div class="numbertext">2 / 3</div>
	  <img src="firstpage2.jpeg" style="width:1000px; height: 360px;">
	</div>

	<div class="mySlides fade">
	  <div class="numbertext">3 / 3</div>
	  <img src="firstpage3.jpeg" style="width:1000px; height: 360px;">
	</div>

	<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
	<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>

<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {
  	slideIndex = 1
  }    
  if (n < 1) {
  	slideIndex = slides.length
  }
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

</body>
</html>