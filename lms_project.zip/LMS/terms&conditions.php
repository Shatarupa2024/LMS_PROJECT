<!DOCTYPE html>
<html>
<head>
  <title>Terms Of Service</title>
  <link rel="stylesheet" href="termStyle.css">
</head>
<body style="font-family: sans-serif;">

    <div class="terms-box">
        <p style="color:red; font-size: 20px; font-weight: bold; font-family: serif;">***Before Registering , Students must read all the <h style="color: black;">Terms and Conditions</h> and then <h style="color: green;">Register</h> if they agree.***</p>
        <div class="terms-text" style="border-color: black; border-style: solid; border-width: 2px; padding-left: 20px; padding-right: 20px;">
            <center><h2 style="font-size: 22px; font-family: serif;"><u>Terms Of Service</u></h2></center>
            
            <p><b>1)</b> Online membership entitles you to use our collections. When you join online library management system you will be given a library ID number for your own personal use. <h style="color: purple;font-weight: bold;">Your library ID number will be your college Roll Number.</h></p>
           
            <p><b>2)</b> Library Users are required to present their library card when they borrow items and use library computers.</p>
            
            <p><b>3)</b> As a library member you are responsible for all items borrowed on your library card,including any lost/damaged items which may need to be paid for.</p>
            
            <p><b>4)</b> A student can issue three books at a time for the period of <h style="color: purple;font-weight: bold;">7 days</h>. A fine of 5 rupees is applicable(per day per book basis),if not returned issued books on or before due date.</p>
            
            <p><b>5)</b> If the card is lost the library must be notified. Replacement card fees of 100 rupees will apply for re-issue of card. </p>

            <p><b>6)</b> If a student want to change Password , Contact number , Email id , etc. then she has to follow these steps.
                <h style="color: purple;font-weight: bold;">Log in to website ->> go to Settings ->> Edit Profile / Change Password.</h></p>

           <p><b>7)</b> Students will update/change their Semester name after the admission through these following steps.
                <h style="color: purple;font-weight: bold;">Log in to website ->> go to Settings ->> Edit Profile.</h></p>

            <p><b>8)</b> Students can Issue and Return books by themselves or by Librarians/Admins.</p>

            <p><b>9)</b> Students can't change their Name and College Roll Number.</p>

            <p><b>10)</b> If there is any problems to Issue and Return books or Change Password , Contact number , etc. then Students will contact the Librarians/Admins.</p>


            <p><h3 style="color: red; font-family: serif;">*** If you accept all these Terms of Condition then press <h style="color: green;">Accept</h> button and then <h style="color: green;">Register</h>. ***</h3></p>
        </div>
        
    <center>
        <div class="buttons">
            <button class="btn green-btn"><a href="studentRegistration_sa.php"><b> Accept </b></a></button>
            &nbsp;
            <button class="btn red-btn"><a href="homePage.php"><b> Cancel </b></a></button>
        </div>
    </center>

    </div>
</body>
</html>
