-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2022 at 12:22 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `ADMIN_ID` varchar(15) NOT NULL,
  `ADMIN_NAME` varchar(20) NOT NULL,
  `ADMIN_EMAIL_ID` varchar(30) NOT NULL,
  `ADMIN_MOBILE_NO` bigint(10) NOT NULL,
  `ADMIN_PASSWORD` varchar(20) NOT NULL,
  `ADMIN_JOINING_DATE` date NOT NULL,
  `ADMIN_MODIFICATION_DATE` date NOT NULL,
  `ADMIN_STATUS` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`ADMIN_ID`, `ADMIN_NAME`, `ADMIN_EMAIL_ID`, `ADMIN_MOBILE_NO`, `ADMIN_PASSWORD`, `ADMIN_JOINING_DATE`, `ADMIN_MODIFICATION_DATE`, `ADMIN_STATUS`) VALUES
('AD01', 'SAHELI PATRA ', 'sahelipatra6@gmail.com', 6291720285, 'sahe', '2022-05-14', '2022-06-19', 'Active'),
('AD02', 'SHATARUPA  DAS  ', 'shatarupa1@gmail.com', 8077421794, 'shatarupa', '2022-05-14', '2022-05-19', 'Active'),
('AD03', 'SREE DAS', 'sre2@gmail.com', 123654789, 'abcd', '2022-05-15', '2022-05-18', 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `booklist`
--

CREATE TABLE `booklist` (
  `ISBN_NO` varchar(30) NOT NULL,
  `BOOK_TITLE` varchar(500) NOT NULL,
  `AUTHOR_NAME` varchar(500) NOT NULL,
  `CATAGORY` varchar(100) NOT NULL,
  `LANGUAGE` varchar(100) NOT NULL,
  `NO_OF_PAGES` varchar(6) NOT NULL,
  `EDITION` varchar(100) NOT NULL,
  `PUBLISHERS` varchar(500) NOT NULL,
  `PRICE` decimal(10,2) NOT NULL,
  `TOTAL_COPY` int(100) NOT NULL,
  `AVAILABLE_COPY` int(100) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `MODIFICATION_DATE` date NOT NULL,
  `STATUS` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booklist`
--

INSERT INTO `booklist` (`ISBN_NO`, `BOOK_TITLE`, `AUTHOR_NAME`, `CATAGORY`, `LANGUAGE`, `NO_OF_PAGES`, `EDITION`, `PUBLISHERS`, `PRICE`, `TOTAL_COPY`, `AVAILABLE_COPY`, `CREATION_DATE`, `MODIFICATION_DATE`, `STATUS`) VALUES
('BK0001', 'Data Structures Using C', 'Reema Thareja', 'Data Structure', 'English', '531', '2nd Edition', 'Oxford University Press', '595.00', 6, 6, '2022-05-12', '2022-05-12', 'Active'),
('BK0002', 'Fundamentals of Digital Circuit', 'A. Anand Kumar', 'Digital Circuit', 'English', '1070', '4th Edition', 'PHI Learning Private Limited', '650.00', 3, 3, '2022-05-12', '2022-05-12', 'Inactive'),
('BK0003', 'Fundamentals of Digital Circuit', 'A. Anand Kumar', 'Digital Circuit', 'English', '990', '2nd Edition', 'PHI Learning Private Limited', '590.00', 5, 4, '2022-05-12', '2022-05-12', 'Active'),
('BK0004', 'Data Communications and Networking', 'Behrouz A. Forouzan', 'Networking', 'English', '1226', '5th Edition', 'McGraw Hill Education (India) Private Limited', '650.00', 2, 2, '2022-05-12', '2022-05-12', 'Inactive'),
('BK0005', 'Data Communications and Networking', 'Behrouz A. Forouzan', 'Networking', 'English', '950', '3rd Edition', 'McGraw Hill Education (India) Private Limited', '430.00', 5, 5, '2022-05-12', '2022-05-12', 'Active'),
('BK0006', 'Microprocessor Architecture, Programming, and Applications with the 8085', 'Ramesh Gaonkar', 'Computer Organization & Architecture', 'English', '814', '6th Edition', 'Penram International Publishing (India) Pvt. Ltd.', '595.00', 3, 3, '2022-05-12', '2022-05-12', 'Active'),
('BK0007', 'Microprocessor Architecture, Programming, and Applications with the 8085', 'Ramesh Gaonkar', 'Computer Organization & Architecture', 'English', '623', '4th Edition', 'Penram International Publishing (India) Pvt. Ltd.', '335.00', 2, 2, '2022-05-12', '2022-05-12', 'Inactive'),
('BK0008', 'Operation System Concepts (Windows XP Update)', 'Silberschatz & Galvin & Gagne', 'Operating System', 'English', '951', '6th Edition', 'Wiley India Pvt. Ltd.', '600.00', 5, 5, '2022-05-12', '2022-05-12', 'Active'),
('BK0009', 'Operation System Concepts (Windows XP Update)', 'Silberschatz & Galvin & Gagne', 'Operating System', 'English', '1050', '9th Edition', 'Wiley India Pvt. Ltd.', '950.00', 2, 2, '2022-05-12', '2022-05-12', 'Active'),
('BK0010', 'C The Complete Reference', 'Herbert Schildt', 'Programming Language', 'English', '805', '4th Edition', 'Tata McGraw Hill Education Pvt. Ltd.', '489.00', 3, 3, '2022-05-12', '2022-05-12', 'Active'),
('BK0011', 'Fundamentals of Microprocessors and Microcontrollers', 'B. Ram', 'Automata Theory', 'English', '495', '9th Edition', 'Dhanpat Rai Publications (P.) Ltd. ', '285.00', 2, 2, '2022-05-12', '2022-05-12', 'Active'),
('BK0012', 'Fundamentals of Microprocessors and Microcontrollers', 'B. Ram', 'Computer Organization & Architecture', 'English', '355', '8th Edition', 'Dhanpat Rai Publications (P.) Ltd.', '250.00', 1, 1, '2022-05-12', '2022-05-12', 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `issued_book_list`
--

CREATE TABLE `issued_book_list` (
  `ISSUE_NO` varchar(20) NOT NULL,
  `ISBN_NO` varchar(10) NOT NULL,
  `STD_ID` varchar(10) NOT NULL,
  `ISSUED_DATE` date NOT NULL,
  `RETURN_DATE` date NOT NULL,
  `RETURN_STATUS` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issued_book_list`
--

INSERT INTO `issued_book_list` (`ISSUE_NO`, `ISBN_NO`, `STD_ID`, `ISSUED_DATE`, `RETURN_DATE`, `RETURN_STATUS`) VALUES
('IS-19-012-AN-01', 'BK0003', '19CMSA012', '2022-06-20', '2022-06-27', 'True'),
('IS-19-012-AN-02', 'BK0001', '19CMSA012', '2022-06-20', '2022-06-27', 'False'),
('IS-19-014-AN-01', 'BK0001', '19CMSA014', '2022-06-20', '2022-06-27', 'False'),
('IS-19-014-AN-02', 'BK0003', '19CMSA014', '2022-06-20', '2022-06-27', 'False'),
('IS-19-014-AN-03', 'BK0003', '19CMSA014', '2022-06-20', '2022-06-27', 'False'),
('IS-19-014-AN-04', 'BK0005', '19CMSA014', '2022-06-20', '2022-06-27', 'False');

-- --------------------------------------------------------

--
-- Table structure for table `return_book_list`
--

CREATE TABLE `return_book_list` (
  `ISSUE_NO` varchar(20) NOT NULL,
  `RETURN_DATE` date NOT NULL,
  `FINE` varchar(5) NOT NULL,
  `FINE_STATUS` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `return_book_list`
--

INSERT INTO `return_book_list` (`ISSUE_NO`, `RETURN_DATE`, `FINE`, `FINE_STATUS`) VALUES
('IS-19-012-AN-02', '2022-06-20', '14', 'CLEARED'),
('IS-19-014-AN-01 ', '2022-06-20', 'N/A', '--'),
('IS-19-014-AN-02', '2022-06-20', 'N/A', '--'),
('IS-19-014-AN-03', '2022-06-20', 'N/A', '--'),
('IS-19-014-AN-04', '2022-06-20', 'N/A', '--');

-- --------------------------------------------------------

--
-- Table structure for table `student_list`
--

CREATE TABLE `student_list` (
  `STD_ID` varchar(15) NOT NULL,
  `STD_NAME` varchar(100) NOT NULL,
  `STD_BATCH` varchar(50) NOT NULL,
  `STD_SEMESTER` varchar(50) NOT NULL,
  `STD_REG_NO` varchar(50) NOT NULL,
  `STD_CONTACT_NO` bigint(10) NOT NULL,
  `STD_EMAIL` varchar(50) NOT NULL,
  `STD_PASSWORD` varchar(50) NOT NULL,
  `STD_JOINING_DATE` date NOT NULL,
  `STD_MODIFICATION_DATE` date NOT NULL,
  `STD_STATUS` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_list`
--

INSERT INTO `student_list` (`STD_ID`, `STD_NAME`, `STD_BATCH`, `STD_SEMESTER`, `STD_REG_NO`, `STD_CONTACT_NO`, `STD_EMAIL`, `STD_PASSWORD`, `STD_JOINING_DATE`, `STD_MODIFICATION_DATE`, `STD_STATUS`) VALUES
('19CMSA001', 'BIDISHA CHATTOPDHYAY', '2019-2022', 'Semester-6', '411-1211-0478-56', 9562341877, 'bids@gmail.com', 'shfcfhvj', '2022-06-20', '2022-06-20', 'Active'),
('19CMSA002', 'NAFISHA SARDAR', '2019-2022', 'Semester-6', '411-1211-0746-19', 8543840653, 'nafisha34@gmail.com', 'nafisha1', '2022-05-15', '2022-05-23', 'Active'),
('19CMSA012', 'ANJANI AHIR', '2019-2022', 'Semester-6', '411-1211-0456-19', 8906664279, 'ahir3@gmail.com', 'anjani', '2022-05-15', '2022-05-15', 'Active'),
('19CMSA014', 'ANKITA MONDAL', '2019-2022', 'Semester-6', '411-1211-0489-19', 9856234175, 'ankita1@gmail.com', 'ankita', '2022-06-20', '2022-06-20', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD UNIQUE KEY `ADMIN_EMAIL_ID` (`ADMIN_EMAIL_ID`),
  ADD UNIQUE KEY `ADMIN_PASSWORD` (`ADMIN_PASSWORD`),
  ADD UNIQUE KEY `ADMIN_MOBILE_NO` (`ADMIN_MOBILE_NO`),
  ADD UNIQUE KEY `ADMIN_ID` (`ADMIN_ID`);

--
-- Indexes for table `booklist`
--
ALTER TABLE `booklist`
  ADD PRIMARY KEY (`ISBN_NO`);

--
-- Indexes for table `issued_book_list`
--
ALTER TABLE `issued_book_list`
  ADD PRIMARY KEY (`ISSUE_NO`);

--
-- Indexes for table `return_book_list`
--
ALTER TABLE `return_book_list`
  ADD UNIQUE KEY `ISSUE_NO` (`ISSUE_NO`);

--
-- Indexes for table `student_list`
--
ALTER TABLE `student_list`
  ADD PRIMARY KEY (`STD_ID`),
  ADD UNIQUE KEY `STD_REG_NO` (`STD_REG_NO`),
  ADD UNIQUE KEY `STD_CONTACT_NO` (`STD_CONTACT_NO`),
  ADD UNIQUE KEY `STD_EMAIL` (`STD_EMAIL`),
  ADD UNIQUE KEY `STD_PASSWORD` (`STD_PASSWORD`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
