<!-- PHP code for connection -->
<?php
session_start();

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lmsdb";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>


<!-- PHP code for insert data in table  -->
<?php
  if(isset($_POST['showPass'])) {

      if($_SERVER["REQUEST_METHOD"] == "POST"){

        @$phone = $_POST['phnumber'];
        @$email = $_POST['email'];
        @$password = $_POST['password']; 

        $password = $row['STD_PASSWORD'];
        $_SESSION['student_passwd'] = $password;

          $query = "SELECT STD_PASSWORD,STD_EMAIL,STD_CONTACT_NO FROM student_list WHERE STD_EMAIL = '$email' AND STD_CONTACT_NO = '$phone'";

          $result = mysqli_query($conn, $query);

          $row = mysqli_fetch_array($result);

          if($row["STD_EMAIL"]== $email && $row["STD_CONTACT_NO"]== $phone){

          $pass = $row["STD_PASSWORD"];
          
          echo '<script> alert("Your Password is : \n'.$pass.'"); </script>';
          echo '<script>window.location = "studentLogin_sa.php";</script>'; 
        }

      else{
            echo '<script> alert("Email-ID or Contact Number Does Not Match !!"); </script>';
            echo '<script>window.location = "studentForgotPassword_sa.php";</script>';
      }

          /*Close the connection.*/
          mysqli_close($conn);
  }
}
?>


<html>
<head>
<title>Forgot Password</title>
<link rel="stylesheet" href="adminStudentLoginStyle_sa.css">
</head>
<body>
<div class="main">
    <form method="post" style="height: 320px;">
      <div class="container">

        <label><b>Email-ID : </b></label><br>
        <input type="email" name="email" id="email" placeholder="Enter your email-id" required><br><br>

        <label><b>Contact Number : </b></label><br>
        <input type="text" name="phnumber" id='number' placeholder="Enter your contact number" required><br>

        <button type="submit" name="showPass" value="Show Password"><b style="font-size: 16px;"> Show Password </b></button> 

        <center><button type="button" class="cancelbtn"><a href="studentLogin_sa.php"><b> Back to Login Form </b></a></button> </center>

      </div>
    </form>
</div>
</body>
</html>