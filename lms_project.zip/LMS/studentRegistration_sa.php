<html>
<head>
  <link rel="stylesheet" href="homepageStyles1.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

  <center>
    <h1 style="font-family: georgia; font-size: 30px; font-weight: bold; color: #09080f;"><u><i> Online Library Management System </i></u></h1>
  </center> 
  <hr>

<div class="marq">
  <marquee behavior="alternate" direction="right">Bijoy Krishna Girls' College , Howrah
  <br>
  &nbsp; &nbsp; &nbsp;Computer Science Department</marquee>
</div>
  <hr>

  <ul>
    <a href="homePage.php"><i class="fa fa-home fa-2x" style="color: black; margin-top: 9px;"></i></a>
    <li><a href="terms&conditions.php"><i> Student Register </i></a></li>
    <li><a href="studentLogin_sa.php"><i> Student Login </i></a></li>
    <li><a href="adminRegistration_sa.php"><i> Admin Register </i></a></li>
    <li><a href="adminLogin_sa.php"><i> Admin Login </i></a></li>
  </ul>

</body>
</html>




<!-- PHP code for connection -->
<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<?php

/* Taking values from the student_table */
	if(isset($_POST['submit'])) {

	    $conn = mysqli_connect($servername, $username, $password, $dbname);
		if($_SERVER["REQUEST_METHOD"] == "POST"){
			
			$student_roll = $_POST['student_clgRoll'];

			$n = $_POST['fname'].' '.$_POST['lname'];
			$name = strtoupper($n);
			$stu_name = $name;

			$batch = $_POST['batch'];
			$semester = $_POST['semester'];
			$reg_number = $_POST['regnumber'];
			$phone = $_POST['phnumber'];
			$email = $_POST['email'];
		    $password = $_POST['password']; 
		    $joining_date = $_POST["joining_date"];
		    $modification_date = $_POST["joining_date"];
		    $status = "Active";

			$query = "SELECT * FROM student_list WHERE STD_ID = '$student_roll'";
			$result = mysqli_query($conn, $query);

			$count = mysqli_num_rows($result);
			if($count == 1){
				echo "<script>alert('Student details already taken..');</script>";
				echo '<script>window.location = "studentRegistration_sa.php";</script>';
			}
			else{
				$reg = "INSERT INTO student_list VALUES ('$student_roll' , '$stu_name' , '$batch' , '$semester' ,  '$reg_number', '$phone' , '$email' , '$password' , '$joining_date' , '$modification_date' , '$status')";
				
				if(mysqli_query($conn, $reg)){
					echo "<script>alert('Registration Successfull...');</script>";
					echo '<script>window.location = "homePage.php";</script>';
				}
				else{
					echo "<script>alert('Unsuccessfull...'.mysqli_error($conn));</script>";
					echo '<script>window.location = "studentRegistration_sa.php";</script>';
				}
			}

			/*Close the connection.*/
			mysqli_close($conn);
		}
	}
?>


<!-- HTML page -->
<html>
<head>
	<link rel="stylesheet" href="adminStudentRegistrationStyle_sa.css">
</head>
<body>
	<div class="main">
	<div class="register">

	<h2 style="color: purple; font-size: 20px;"><u>Register Here</u></h2>

	<form method="post">

	<label><b> Student Roll No. : </b></label><br>
	<input type="text" name="student_clgRoll" id="number" placeholder="Enter your college roll_no" required><br><br>

	<label><b> First Name : </b></label><br>
	<input type="text" name="fname" id="name" placeholder="Enter your first name" required><br><br>

	<label><b> Last Name : </b></label><br>
	<input type="text" name="lname" id="name" placeholder="Enter your last name" required><br><br>

	<label><b> Batch : </b></label><br>
	<select name="batch" id="name" required>
		<option value="2017-2020">2017-2020</option>
		<option value="2018-2021">2018-2021</option>
		<option value="2019-2022">2019-2022</option>
		<option value="2020-2023">2020-2023</option>
		<option value="2021-2024">2021-2024</option>
		<option value="2022-2025">2022-2025</option>
	</select><br><br>

	<label><b> Semester : </b></label><br>
	<select name="semester" id="name" required>
		<option value="Semester-1">Semester-1</option>
		<option value="Semester-2">Semester-2</option>
		<option value="Semester-3">Semester-3</option>
		<option value="Semester-4">Semester-4</option>
		<option value="Semester-5">Semester-5</option>
		<option value="Semester-6">Semester-6</option>
	</select><br><br>
	

	<label><b> Registration Number : </b></label><br>
	<input type="text" name="regnumber" id="number" placeholder="Enter your registration number." required><br><br>

	<label><b> Contact Number : </b></label><br>
	<input type="text" name="phnumber" id="number"  minlength="10" maxlength="10" placeholder="Enter your contact number" pattern="[6789][0-9]{9}" required><br><br>

	<label><b> Email id : </b></label><br>
	<input type="email" name="email" id="email" placeholder="Enter your valid email-id" required pattern="[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9-]+.[a-z]{2,4}" title="Invalid email."><br><br>

	<label><b> Password : </b></label><br>
    <input type="password" placeholder="enter the password" name="password" id="password" required><br><br>

   	<label><b> Date : </b></label> <br> 
	<input type="text" name="joining_date" id="name" value="<?php echo Date('Y-m-d') ?>" readonly required> <br><br> 

	<input type="checkbox" name="check" required>By creating an account you agree to our <h style="color: black;"> Terms & Conditions<br><br>

	<div class = "submit-btn">
	<input type="submit" value="Submit" name="submit" id="submit"></div><br>

	<span class="psw" style="font-family: georgia;"> Already registered ? <a href="studentLogin_sa.php"> Log in </a></span>

</form>
</div>
</body>
</html>