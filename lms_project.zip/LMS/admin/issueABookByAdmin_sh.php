<!-- PHP code for connection -->

<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>


<!--HTML Code -->

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="addBookStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
	    	<li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
	    	<li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
	    	<li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2><u>Issue A Book</u></h2><br>
		<div class="form">
		<form method="POST">

		<label for="student id">Student Roll Number : </label>
		<input type="text" name="sId" id="name" required>
		<button type="submit" formaction="populateIssueNoFromIssuePage_sh.php" method="post"  style="float: right; margin-right: 17px;  margin-top: 6px; background-color: rgba(128,128,128,0.3); border: 1px solid #f1f1f1; color: black; font-size: 17px; padding: 3px;">Go</button>
        <br><br>

		<label for="book issue no">Issue number : </label>
		<input style="color: blue;" type="text" name="issueNo" id="name" readonly required>
		<br><br>

		<label for="isbn no">Book ISBN No : </label>
		<input type="text" name="isbnNo" id="name" readonly required>
		<br><br>

		<label for="issue date">Issue Date : </label> <br> 
		<input type="date" name="iDate" id="name" value="<?php echo date('Y-m-d')?>" readonly required><br><br> 
		
		<label for="return date">Return Date : </label> <br> 
		<input type="date" name="rDate" id="name" value="<?php
			$today = date('Y-m-d');
			$new = strtotime("+7 day",strtotime($today));
			$rdate = date('Y-m-d', $new);
			echo $rdate; ?>" readonly required><br><br>
		<div class="submitButton">
		<input type="submit" value="ISSUE" name="issue" id="submit" disabled>
		<br><br>
		</div>

		
	</div>
	<form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
	</form>
	</div>

</body>
</html>