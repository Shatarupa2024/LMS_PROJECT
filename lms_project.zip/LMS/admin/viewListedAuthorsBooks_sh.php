<!-- PHP code for connection -->

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
    
   // mysqli_close($conn);
?>

<!-- php for view books of a perticular catagory -->

<?php

    if(isset($_POST['viewBook'])) {
        $auth = $_POST['auth'];
        $query = "SELECT BOOK_TITLE FROM booklist WHERE CATAGORY = '$auth'";
        $result = mysqli_query($conn, $query);

        
    }

?>

<!-- HTML page -->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <h2 align="center"><u>All books by <?php echo $auth; ?></u></h2><br>
        <table  id = "table" align="center">
            <tr>
                <th>Title</th>
                <th>Edition</th>
                <th>Status</th>
                <th colspan="3" style="text-align: center;">Action</th>
            </tr>

            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
        <?php
            $query = "SELECT ISBN_NO,BOOK_TITLE,EDITION,STATUS FROM booklist WHERE AUTHOR_NAME='$auth'";
            $result = mysqli_query($conn, $query);
            while($rows = mysqli_fetch_assoc($result))
            {

                //echo $rows['BOOK_TITLE'];
        ?>
        <tr>
            <!--fetch catagory from booklist-->
            <td><?php echo $rows['BOOK_TITLE'];?></td>
            <td><?php echo $rows['EDITION'];?></td>
            <td><?php echo $rows['STATUS'];?></td>            
            <form action="viewDetailsBook_sh.php" method="POST">
                <input type="hidden" name="bIsbn" value="<?php echo $rows['ISBN_NO']; ?>">
                <td><input type="submit" name="view" class="btn btn-success" value="View Details"></td>
            </form>
            <form action="modifyBook_sa.php" method="POST">
                <input type="hidden" name="bIsbn" value="<?php echo $rows['ISBN_NO']; ?>">
                <td><input type="submit" name="view" class="btn btn-success" value="Modify"></td>
            </form>
            <form action="issueABookByAdminFromBooks_sh.php" method="POST">
                <input type="hidden" name="bIsbn" value="<?php echo $rows['ISBN_NO']; ?>">
                <td><input type="submit" name="view" class="btn btn-success" value="Issue"></td>
            </form>


        </tr>
        <?php
            } //end while loop
        ?>
        </table><br><br>
        <form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
    </div>
</body>
</html>