<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<?php
/*check connection */
if($conn == false){
    die("ERROR: Connection failed".mysqli_connect.error());
}

// SQL query to select data from database
$s = "SELECT * FROM admin_table";

$result = mysqli_query($conn, $s);

/*Close the connection.*/
mysqli_close($conn);
?>
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <h2 align="center"><u>Admin's Details:</u></h2><br>
        <table id = "table" align="center">
            <tr>
                <th>Admin Id</th>
                <th>Name</th>
                <th>Email Id</th>
                <th>Contact number</th>
                <th>Joining Date</th>
                <th>Modification Date</th>
                <th>Status</th>
            </tr>
            
        <?php   // LOOP TILL END OF DATA 
            while($rows = mysqli_fetch_array($result))
            {
        ?>
        <tr>
            <!--fetching data from each row of every column-->
                <td><?php echo $rows['ADMIN_ID'];?></td>
                <td><?php echo $rows['ADMIN_NAME'];?></td>
                <td><?php echo $rows['ADMIN_EMAIL_ID'];?></td>
                <td><?php echo $rows['ADMIN_MOBILE_NO'];?></td>
                <td><?php echo $rows['ADMIN_JOINING_DATE'];?></td>
                <td><?php echo $rows['ADMIN_MODIFICATION_DATE'];?></td>
                <td><?php echo $rows['ADMIN_STATUS'];?></td>
        </tr>

        
        <?php
            }
        ?>
        </table>
        <br><br><h4><b><a href="memberSection.php" style="margin-left: 20px;">Go to previous page</a></b></h4>
    </div>
</body>
</html>