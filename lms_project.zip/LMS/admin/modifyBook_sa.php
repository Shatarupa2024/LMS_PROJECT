<!-- PHP code for connection -->

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
?>


<!-- PHP code for insert data in table  -->

<?php
    if(isset($_POST['update'])){

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $isbnNo = $_POST["bIsbn"];
            @$bookTitle = $_POST["bTitle"];
            @$auother = $_POST["bAuthor"];
            @$catagory = $_POST["bCatagory"];
            @$language = $_POST["bLanguage"];
            @$pages = $_POST["bPages"];
            @$edition = $_POST["bEdition"];
            @$publishers = $_POST["bPublishers"];
            @$price = $_POST["bPrice"];
            @$createDate = $_POST["creationDate"];
            @$modificationDate = $_POST["modificationDate"];
            @$status = $_POST["status"];

                $query2 = "UPDATE booklist SET  BOOK_TITLE = '$bookTitle', AUTHOR_NAME = '$auother', CATAGORY = '$catagory', PUBLISHERS = '$publishers', EDITION = '$edition', LANGUAGE = '$language', PRICE = '$price', NO_OF_PAGES = '$pages', MODIFICATION_DATE = '$modificationDate', STATUS = '$status' WHERE ISBN_NO = '$isbnNo'";

                $result2 = mysqli_query($conn, $query2);

                echo '<script> alert("Book Updated Successfully."); </script>';
                echo '<script>window.location = "viewListedBook_sa.php"; </script>';
            }
            else{
                echo '<script> alert("Book not updated"); </script>';
                echo '<script>window.location = "viewListedBook_sa.php";</script>';
            }      
    }
?>
<!-- HTML page -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="addBookStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueBook.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogOut.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
         <h2><u>Modify This Book</u></h2><br>
        <div class="form">
        <form method="POST">

        <label for="bookIsbnNo">Book ISBN number : </label>
        <input style="color: blue;" type="text" name="bIsbn" id="name" value="<?php echo $_POST['bIsbn']; ?>" readonly required>
        <br><br>

        <?php
        $isbnNo = $_POST['bIsbn']; 
        $query = "SELECT * FROM booklist WHERE ISBN_NO = '$isbnNo'";
        $result = mysqli_query($conn, $query);

        while($rows = mysqli_fetch_array($result)) {

        ?>

        <label for="bookTitle">Book Name : </label>&nbsp;
        <input type="text" name="bTitle" id="name" value="<?php echo $rows['BOOK_TITLE'] ?>" required>
        <br><br>

        <label for="authorName">Author : </label> <br>
        <input type="text" name="bAuthor" id="name" value="<?php echo $rows['AUTHOR_NAME'] ?>" required>
        <br><br>

        <label for="catagory">Catagory : </label> <br>
        <select name="bCatagory" id="name" value="<?php echo $rows['CATAGORY'] ?>" required>
        
        <?php
            if($rows['CATAGORY'] == $_POST['bCatagory']) {
                echo "<option value='" . $rows['CATAGORY'] ."' selected>" . $rows['CATAGORY'] . "</option>";
            }
            else{
                echo "<option value='" . $rows['CATAGORY'] ."'>" . $rows['CATAGORY'] . "</option>";
            }
        ?>
            <option value="Automata Theory">Theory Of Computer Science (TOC)</option>
            <option value="Software Engineering">Software Engineering</option>
            <option value="Operating System">Operating System</option>
            <option value="Multimedia">Multimedia</option>
            <option value="Programming Language">Programming Language</option>
            <option value="Data Structure">Data Structure</option>
            <option value="Digital Circuit">Digital Circuit</option>
            <option value="Computer Organization & Architecture">Computer Organization & Architecture</option>
            <option value="Networking">Networking</option>
            <option value="Digital Image Processing">Digital Image Processing</option>
            <option value="Database Management System">Database Management System</option>
            <option value="Graphics">Graphics</option>
        </select> <br><br>

        <label for="publishers">Publishers : </label> <br>
        <input type="text" name="bPublishers" id="name" value="<?php echo $rows['PUBLISHERS'] ?>" required> 
        <br><br>

        <label for="edition">Edition : </label> <br>
        <input type="text" name="bEdition" id="name" value="<?php echo $rows['EDITION'] ?>" required> <br><br>

        <label for="language">Language : </label>&nbsp;
        <select name="bLanguage" id="name" value="<?php echo $rows['LANGUAGE'] ?>" required>
            <option value="English">English</option>
        </select> <br><br>

        <label for="price">Price : </label> <br>
        <input type="number" name="bPrice" id="name" value="<?php echo $rows['PRICE'] ?>" required> <br><br>

        <label for="pages">Number of pages : </label> <br>
        <input type="number" name="bPages" id="name" value="<?php echo $rows['NO_OF_PAGES'] ?>" required> 
        <br><br>

        <label for="modificationDate">Date : </label> <br> 
        <input type="text" name="modificationDate" id="name" value="<?php echo Date('Y-m-d') ?>" readonly required> <br><br> 

        <label for="status">Status : </label>&nbsp;&nbsp;&nbsp;
        <input type="radio" name="status" <?php if($rows['STATUS'] == "Active") { echo "checked";} ?> value="Active"> Active &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="status" <?php if($rows['STATUS'] == "Inactive") { echo "checked";} ?> value="Inactive" > Inactive
        <br><br>

        <?php 
            }
        ?>

        <div class="submitButton">
        <input type="submit" value="UPDATE" name="update" id="submit">
        <br><br>
        </div>

        
    </div>
    
    <form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br>
    </form>
</div>
</body>
</html>