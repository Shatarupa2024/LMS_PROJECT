<!-- PHP code for connection -->

<?php
session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for store the value -->

<?php

	$issueNo = $_POST['issueNo'];
	$rDate = date('Y-m-d');
	$fine = $_POST['fine'];
	$fineStatus = "CLEARED";

	$q = "UPDATE return_book_list SET FINE_STATUS = 'CLEARED', RETURN_DATE = '$rDate' WHERE ISSUE_NO = '$issueNo'";

	if (mysqli_query($conn, $q)) {
		
		//echo "<script>window.location = 'adminIssueReturnSec.php'; </script>";

		$q1 = "UPDATE issued_book_list SET RETURN_STATUS = 'False' WHERE ISSUE_NO = '$issueNo'";
		mysqli_query($conn, $q1);

		$query = "SELECT * FROM issued_book_list WHERE ISSUE_NO = '$issueNo'";
		$result = mysqli_query($conn, $query);
		$rows = mysqli_fetch_assoc($result);
		$isbn = $rows['ISBN_NO'];

		$q2 = "UPDATE booklist SET AVAILABLE_COPY = AVAILABLE_COPY + 1 
				WHERE ISBN_NO = '$isbn'";
		mysqli_query($conn, $q2);

		echo "<script>alert('Fine cleared. Book successfully returned.');</script>";
		echo "<script>window.location = 'adminIssueReturnSec.php'; </script>";
		
	} else{
		echo "<script>alert('Your fine is pending for this book. Contact with admin.');</script>";
		echo "<script>window.location = 'adminIssueReturnSec.php'; </script>";
	}



?>