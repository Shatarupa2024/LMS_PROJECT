<!-- PHP code for connection -->
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }

    if(isset($_POST['view'])){

        $query = "SELECT * FROM student_list WHERE STD_ID = '".$_POST['student_clgRoll']."'";
        $result = mysqli_query($conn, $query);
        mysqli_close($conn);
    }
?>


<!-- HTML page -->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle2_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <br><br>
        <table id = "table" align="center" cellspacing="0" cellpadding="0">
        <?php
            while($rows = mysqli_fetch_array($result))
            {
        ?>
            <tr>
                <td>Student Id</td>
                <td><?php echo $rows['STD_ID'];?></td>
                <td> </td>
                <td>Name</td>
                <td><?php echo $rows['STD_NAME'];?></td>
            </tr>
            <tr>
                <td>Batch</td>
                <td><?php echo $rows['STD_BATCH'];?></td>
                <td> </td>
                <td>Semester</td>
                <td><?php echo $rows['STD_SEMESTER'];?></td>
            </tr>
            <tr>
                <td>Registration Number</td>
                <td><?php echo $rows['STD_REG_NO'];?></td>
                <td> </td>
                <td>Contact number</td>
                <td><?php echo $rows['STD_CONTACT_NO'];?></td>
            </tr>
            <tr>
                <td>Email Id</td>
                <td><?php echo $rows['STD_EMAIL'];?></td>
                <td> </td>
                <td>Status</td>
                <td><?php echo $rows['STD_STATUS'];?></td>
            </tr>
            <tr>
                <td>Joining Date</td>
                <td><?php echo $rows['STD_JOINING_DATE'];?></td>
                <td> </td>
                <td>Modification Date</td>
                <td><?php echo $rows['STD_MODIFICATION_DATE'];?></td>
            </tr>

        
        <?php
            }
        ?>
            </tr>
            <tr><td></td><td></td><td><form><input type="button" value="Back" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: Green; font-size: 15px; font-weight: bold;"></form></td><td></td><td></td></tr>
        </table>
    </div>
</body>
</html>