<!-- PHP code for connection -->

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
    
    if(isset($_POST['searchIssueByBookId'])){

        @$isbnNo = $_POST["bIsbn"];

        $query = "SELECT * FROM booklist";
        $result = mysqli_query($conn, $query);
    }
?>

<!-- HTML page -->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>

    <div class="container">
        <?php 
            $result = mysqli_query($conn, "SELECT * FROM issued_book_list WHERE ISBN_NO= '$isbnNo'");
            if(mysqli_num_rows($result) == 0){
                echo '<script> alert("Data Not Found !!"); history.go(-1);</script>';
            } else {
                

        ?>
        <h2 align="center"><u>List Of Issued Books</u></h2><br>

        <table  id = "table" align="center">
            <tr>
                <th>Issue No.</th>
                <th>Student ID</th>
                <th>Book ISBN No.</th>
                <th>Issued Date</th>
                <th>Return Date</th>
                <th>Return Status</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
        <?php   // LOOP TILL END OF DATA 
            while($rows = mysqli_fetch_assoc($result))
            {
        ?>
        <tr>
            <!--fetching data from each row of every column-->
            <td><?php echo $rows['ISSUE_NO'];?></td>
            <td><?php echo $rows['STD_ID'];?></td>
            <td><?php echo $rows['ISBN_NO'];?></td>
            <td><?php echo $rows['ISSUED_DATE'];?></td>
            <td><?php echo $rows['RETURN_DATE'];?></td>
            <?php 
            if($rows['RETURN_STATUS'] == 'False') {
                echo "<td>Returned</td>"; 
            } else {
                echo "<td>Not Returned</td>"; 
            }
           ?>
        </tr>
        <?php
            }
         }
        ?>
        </table><br><br>
        <form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
    </div>
</body>
</html>