<!-- PHP code for connection -->

<?php
session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for store the value -->

<?php

	$issueNo = $_POST['issueNo'];

	$rDate = $_POST['rDate'];

	$fine = "NA";

	$fineStatus = "--";

	$query = "SELECT * FROM return_book_list WHERE ISSUE_NO = '$issueNo'";
	$result = mysqli_query($conn, $query);

	if(mysqli_num_rows($result) == 0){
		$q = "INSERT INTO return_book_list VALUES ('$issueNo', '$rDate', '$fine', '$fineStatus')";
		mysqli_query($conn, $q);
		echo "<script>alert('Return successfully.'); history.go(-2); </script>";

		$q1 = "UPDATE issued_book_list SET RETURN_STATUS = 'False' WHERE ISSUE_NO = '$issueNo'";
		mysqli_query($conn, $q1);

		$q2 = "SELECT ISBN_NO FROM issued_book_list WHERE ISSUE_NO = '$issueNo'";
		$rs = mysqli_query($conn, $q2);
		$row = mysqli_fetch_array($rs);
		$isbn = $row['ISBN_NO'];

		$q2 = "UPDATE booklist SET AVAILABLE_COPY = AVAILABLE_COPY + 1 
				WHERE ISBN_NO = '$isbn'";
		mysqli_query($conn, $q2);
		
	} else{
		$q = "UPDATE return_book_list SET 
				RETURN_DATE = '$rDate',
				FINE = '$fine',
				FINE_STATUS = '$fineStatus' WHERE ISSUE_NO = '$issueNo'";
		mysqli_query($conn, $q);
		echo "<script>alert('Return successfully.'); history.go(-2);</script>";

		$q1 = "UPDATE issued_book_list SET RETURN_STATUS = 'False' WHERE ISSUE_NO = '$issueNo'";
		mysqli_query($conn, $q1);

		$q2 = "SELECT ISBN_NO FROM issued_book_list WHERE ISSUE_NO = '$issueNo'";
		$rs = mysqli_query($conn, $q2);
		$row = mysqli_fetch_array($rs);
		$isbn = $row['ISBN_NO'];

		$q2 = "UPDATE booklist SET AVAILABLE_COPY = AVAILABLE_COPY + 1 
				WHERE ISBN_NO = '$isbn'";
		mysqli_query($conn, $q2);
		
	}

?>
