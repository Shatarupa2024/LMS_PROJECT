
<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
	    	<li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
	    	<li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
	    	<li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<div class="header">
			<br><h2>Library Manegment System | View Reports</h2>
		</div>
		<!--<div class="search">
            <form action="#">
                <input type="text" placeholder=" Search... " name="search">
    			<button>
                    <i class="fa fa-search"></i>
            	</button>
            </form>
        </div>-->
		<div class="content">
			<div class="cards">
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewIssuedBook_sh.php"><i class="fas fa-book-open fa-4x"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT * FROM issued_book_list");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewListedBook_sa.php"><h3>View Issued Books</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewReturnedBook_sh.php"><i class="fa fa-group fa-4x"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT DISTINCT * FROM return_book_list");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewListedAuthor_sh.php"><h3>View Returned Books</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewBooksAreNotReturnYetByAdmin_sh.php"><i class="fas fa-recycle fa-4x"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT * FROM issued_book_list WHERE RETURN_STATUS='True'");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewBooksAreNotReturnYetByAdmin_sh.php"><h3>Books Are Not Return Yet</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewFine_sh.php"><i class="fas fa-file-invoice-dollar fa-4x" style="color: rgb(92,73,115);"></i></a>
						</div>
						<a href="viewFine_sh.php"><h3>View Generated Fine</h3></a>
					</div>
				</div>
				</div>
			</div>	
		</div>
	</div>

</body>
</html>