<!-- PHP code for connection -->

<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!--HTML Code -->

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="addBookStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
	    	<li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
	    	<li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
	    	<li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2><u>Return A Book</u></h2><br>
		<div class="form">
		<form method="POST">

		<label for="student id">Student Roll Number : </label>
		<input type="text" name="sId" id="name" value="<?php echo $_POST['sId']; ?>" required>
		<button type="submit" formaction="populateIssueNoForReturnPage_sh.php" method="post"  style="float: right; margin-right: 17px;  margin-top: 6px; background-color: rgba(128,128,128,0.3); border: 1px solid #f1f1f1; color: black; font-size: 17px; padding: 3px;">Go</button>
        <br><br>

        <label for="book issue no">Select Issue Number : </label>
        <select name="issueNo" id="name" required> 
		<?php
        $s_id = $_POST['sId'];
        $q = "SELECT * FROM student_list WHERE STD_ID = '$s_id'";
        $rs = mysqli_query($conn, $q);
        $r = mysqli_fetch_assoc($rs);

        $q1 = "SELECT * FROM issued_book_list WHERE STD_ID = '$s_id'";
        $rs1 = mysqli_query($conn, $q1);
        $r1 = mysqli_fetch_assoc($rs1);

        if (mysqli_num_rows($rs) == 0) {
        	echo "<script>alert('Student not found!');</script>";
        	echo "<script>window.location = 'returnABookByAdmin_sh.php'; </script>";
        } else if (mysqli_num_rows($rs1) == 0) {
        	echo "<script>alert('No books are issued by this student.');</script>";
        	echo "<script>window.location = 'returnABookByAdmin_sh.php'; </script>";
        } else {
        	$name = $r['STD_NAME'];
    		$sName = substr($name, 0, 2);
    		$sBatch = substr($s_id, 0, 2);
    		$sId = substr($s_id, 6);
    		$iNo = "IS-" . $sBatch . "-". $sId . "-" . $sName . "-";
    		$query = "SELECT * FROM issued_book_list WHERE ISSUE_NO LIKE '$iNo%' AND RETURN_STATUS = 'True'";
			$result = mysqli_query($conn,$query);
			if ($result) {

				if (mysqli_num_rows($result) == 0) {

					echo "<script>alert('This book are not issued by this student.');</script>";
					echo "<script>window.location = 'returnABookByAdmin_sh.php'; </script>";
				} else {
						//echo "Hi";
					while ($rows = mysqli_fetch_array($result)) {
						if ($rows['ISSUE_NO'] == $_POST['issueNo']) {
							echo "<option value='" . $rows['ISSUE_NO'] . "' selected >" . $rows['ISSUE_NO'] . "</option>";
						} else {
							echo "<option value='" . $rows['ISSUE_NO'] . "'>" . $rows['ISSUE_NO'] . "</option>";
						}
					}
				}
        	} else {
					echo mysqli_error();
			}
		}
    	?>
		</select>
		<button type="submit" formaction="populateISBNNoForReturnPage_sh.php" method="post"  style="float: right; margin-right: 17px;  margin-top: 6px; background-color: rgba(128,128,128,0.3); border: 1px solid #f1f1f1; color: black; font-size: 17px; padding: 3px;">Go</button>
        <br><br>

        <label for="isbn no">Book ISBN No : </label>
        <?php
        $issueNo = $_POST['issueNo'];
        $q = "SELECT * FROM issued_book_list WHERE ISSUE_NO = '$issueNo'";
        $rs = mysqli_query($conn,$q);
        $r = mysqli_fetch_array($rs);
        $isbn = $r['ISBN_NO'];
        ?>
		<input type="text" name="isbnNo" id="name" value="<?php echo $isbn; ?>" readonly required>
		<br><br>

		<label for="book title">Book Title : </label>
		<?php
        $q1 = "SELECT BOOK_TITLE FROM booklist WHERE ISBN_NO = '$isbn'";
        $rs1 = mysqli_query($conn,$q1);
        $r1 = mysqli_fetch_array($rs1);
        $bTitle = $r1['BOOK_TITLE'];
        ?>
		<input type="text" name="bTitle" id="name" value="<?php echo $bTitle; ?>" readonly required>
		<br><br>
		<label for="return date">Return Date : </label> <br> 
		<input type="date" name="rDate" id="name" value="<?php echo date('Y-m-d'); ?>" readonly required><br><br> 
		<label for="fine">Fine : </label> <br> 
		<?php

		$date2 = strtotime(date('Y-m-d'));
		$date1 = strtotime($r['RETURN_DATE']);
		//Get the difference and divide into total no. seconds 60/60/24 to get number of days
		$days = ($date1 - $date2)/60/60/24 ;
		if ($days == 0 | $days < 0) {
			$fine = "Fine Not Generated";
		} else {
			$days = doubleval($days);
			$fine = doubleval($days * 2);
			$fine = strval($fine);
		}
		if($fine == "Fine Not Generated") {
		?>
			<input type="text" name="fine" id = "name" value = "<?php echo $fine; ?>" readonly required>
			<br><br>
			<div class="submitButton">
			<button type="submit" id="submit" formaction="storeFineByAdminNa_sh.php" mathod="POST">Submit</button></div>

		<?php 

		}	else {

		?>
			<input type="text" name="fine" id = "name" value = "<?php echo $fine; ?>" readonly required>
			<br><br>
			<div class="submitButton">
			<button type="submit" id="submit" formaction="storeFineByAdmin_sh.php" mathod="POST">Go To Next Page</button></div>

		<?php 
		} ?>
    
	</div>
	<form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 35px;"></form><br><br>
	</form>
</div>
</body>
</html>