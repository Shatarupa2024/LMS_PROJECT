<!-- PHP code for connection -->

<?php
session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
    $query = "SELECT * FROM admin_table";
    $result = mysqli_query($conn, $query);
    //mysqli_close($conn);
?>

<?php
if(isset($_POST['inactive'])) {
    $admin_id = $_POST['admin_id'];

    $query = "UPDATE admin_table SET ADMIN_STATUS = 'Inactive' WHERE ADMIN_ID ='$admin_id'";
    mysqli_query($conn, $query);
    echo "<script>alert('Update Successfull.');</script>";

    $date = Date('Y-m-d');

    $query1 = "UPDATE admin_table SET ADMIN_MODIFICATION_DATE = '$date' WHERE ADMIN_ID ='$admin_id'";
    mysqli_query($conn, $query1);
    
}

?>

<?php 
if(isset($_POST['active'])) {
    $admin_id = $_POST['admin_id'];

    $query = "UPDATE admin_table SET ADMIN_STATUS = 'Active' WHERE ADMIN_ID ='$admin_id'";
    mysqli_query($conn, $query);
    echo "<script>alert('Update Successfull.');</script>";

    $date = Date('Y-m-d');

    $query1 = "UPDATE admin_table SET ADMIN_MODIFICATION_DATE = '$date' WHERE ADMIN_ID ='$admin_id'";
    mysqli_query($conn, $query1);
}
?>

<!--html page-->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <h2 align="center"><u>Admin's Settings</u></h2><br>
        <table id = "table" align="center">
            <tr>
                <th>Admin Id</th>
                <th>Name</th>
                <th colspan="3" style="text-align: center;">Action</th>
            </tr>
            
        <?php   // LOOP TILL END OF DATA 
            while($rows = mysqli_fetch_array($result))
            {
        ?>
        <tr>
            <!--fetching data from each row of every column-->
                <td><?php echo $rows['ADMIN_ID'];?></td>
                <td><?php echo $rows['ADMIN_NAME'];?></td>
                <form action="adminViewProfile_sa.php" method="POST">
                    <input type="hidden" name="admin_id" value="<?php echo $rows['ADMIN_ID'] ?> ">
                    <td><input type="submit" name="view" class="btn btn-success" value="View Profile"></td>
                </form>
                
                <form method="post">
                    <input type="hidden" name="admin_id" value="<?php echo $rows['ADMIN_ID'] ?>">
                    <td><input type="submit" name="inactive" class="btn btn-danger" value="Inactive"></td>
                </form>
                <form method="post">
                    <input type="hidden" name="admin_id" value="<?php echo $rows['ADMIN_ID'] ?>">
                    <td><input type="submit" name="active" class="btn btn-success" value="Active"></td>
                </form>
        </tr>

        
        <?php
            }
        ?>
        </table>
        <form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
    </div>
</body>
</html>