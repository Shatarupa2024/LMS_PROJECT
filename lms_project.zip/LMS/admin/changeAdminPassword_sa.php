<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
?>

<?php
if(isset($_POST['changePassword'])) {
    @$admin_id = $_POST['admin_id'];
	@$old_Passwd = $_POST['old_password'];
	@$new_Passwd = $_POST['new_password'];
     @$modification_date = $_POST["modification_date"];

	$query = "SELECT ADMIN_PASSWORD FROM admin_table WHERE ADMIN_PASSWORD = '$old_Passwd'";
	$result = mysqli_query($conn, $query);

	$rows = mysqli_fetch_array($result);
    if($rows == 0){
        echo '<script> alert("Old Password Does Not Match"); </script>';
    }
    	if($rows){
    		
    		$query2 = "UPDATE admin_table SET ADMIN_PASSWORD ='$new_Passwd' , ADMIN_MODIFICATION_DATE = '$modification_date' WHERE ADMIN_PASSWORD ='$old_Passwd'";
    		$result2 = mysqli_query($conn, $query2);
    		
    		echo '<script> alert("Password Changed Succesfully .."); </script>';
    			//header("location:adminSettings.php");
    	}
}
?>

<!-- HTML page -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
<link rel="stylesheet" type="text/css" href="changePasswd.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script type="text/javascript"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="main">
            <div class="register">
                <form method="post">

    				<label>Old Password : </label><br>
    				<input type="password" name="old_password" id="password" required><br><br>

    				<label>New Password : </label><br>
    				<input type="password" name="new_password" id="password" required><br><br>

                    <label>Date : </label> <br> 
                    <input type="text" name="modification_date" id="name" value="<?php echo Date('Y-m-d    H:i:s') ?>" readonly required> <br><br> 
    			
                    <div class="submit-btn">
    				<input type="submit" id="submit" name="changePassword" value="CHANGE PASSWORD">
                    <br><br>
                    </div>
	           </form>
        </div></div>
<h4><b><a href="adminSettings.php" style="margin-left: 20px;">Go to previous page</a></b></h4>
</div>
</body>
</html>