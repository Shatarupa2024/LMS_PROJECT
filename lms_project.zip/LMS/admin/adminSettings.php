<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
	    	<li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
	    	<li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
	    	<li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<div class="header">
			<br><h2>Library Manegment System | Settings</h2>
		</div>
		<!--<div class="search">
            <form action="#">
                <input type="text" placeholder=" Search... " name="search">
    			<button>
                    <i class="fa fa-search"></i>
            	</button>
            </form>
        </div>-->
		<div class="content">
			<div class="cards">
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="settingsAdmin_sa.php"><i class="fas fa-portrait fa-4x"  style="color: rgb(92,73,115);"></i></a>
						</div>
						<a href="settingsAdmin_sa.php"><h3>Admin's Settings</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="settingsStudent_sa.php"><i class="fa fa-user fa-4x"  style="color: rgb(92,73,115);"></i></a>
						</div>
						<a href="settingsStudent_sa.php"><h3>Student's Settings</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="editAdminProfile_sa.php"><i class="fa fa-user-circle fa-4x"  style="color: rgb(92,73,115);"></i></a>
						</div>
						<a href="editAdminProfile_sa.php"><h3>Update Your Profile</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="changeAdminPassword_sa.php"><i class="fas fa-unlock fa-4x"  style="color: rgb(92,73,115);"></i></a>
						</div>
						<a href="changeAdminPassword_sa.php"><h3>Change Your Password</h3></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>