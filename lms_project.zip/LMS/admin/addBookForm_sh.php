<!-- PHP code for connection -->

<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for auto increment the isbn no -->

<?php
	$query = "SELECT * FROM booklist ORDER BY ISBN_NO DESC LIMIT 1";
    $result = mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result);
	@$last_isbn_no = $row['ISBN_NO'];
	if ($last_isbn_no == "") {
		$isbn_no = "BK0001";
	}
	else {
		$num = substr($last_isbn_no, 2); //then num = 0001
		$digit = intval($num); //convert string 0001 to integer
		$digit = $digit + 1; // 0001 + 1 = 2 but want 0002 so,
		$get_string = str_pad($digit, 4, 0, STR_PAD_LEFT); // get 0002 as string type 
		$isbn_no = "BK" . $get_string;
	}
?>

<!-- PHP code for insert data in table  -->

<?php
	
	if(isset($_POST['addbook'])) {

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $isbnNo = $_POST["bIsbn"];
            $bookTitle = $_POST["bTitle"];
            $auother = $_POST["bAuthor"];
            $catagory = $_POST["bCatagory"];
            $language = $_POST["bLanguage"];
            $pages = $_POST["bPages"];
            $edition = $_POST["bEdition"];
            $publishers = $_POST["bPublishers"];
            $price = $_POST["bPrice"];
            $totalCopy = $_POST["noOfCopies"];
            $availableCopy = $_POST["noOfCopies"];
            $createDate = $_POST["creationDate"];
            $modificationDate = $_POST["creationDate"];
            $status = $_POST["status"];
            if (!$conn)
            {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "INSERT INTO booklist VALUES ('$isbnNo', '$bookTitle', '$auother', '$catagory', 
            	'$language', '$pages', '$edition', '$publishers', '$price', '$totalCopy','$availableCopy', '$createDate', '$modificationDate', '$status')";
            if (mysqli_query($conn, $sql)) { 
            	echo "<script>alert('New record created successfully');</script>";
          	 } else {
                echo "<script>alert('Error: ".$sql."\n".mysqli_error($conn)."');</script>";

            }
            mysqli_close($conn);
        }
    }
?>


<!-- HTML page -->

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="addBookStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
	    	<li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
	    	<li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
	    	<li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2><u>Add A Book</u></h2><br>
		<div class="form">
		<form method="POST">
		<label for="bookIsbnNo">Book ISBN number : </label>
		<input style="color: blue;" type="text" name="bIsbn" id="name" value="<?php echo $isbn_no; ?>" readonly required>
		<br><br>

		<label for="bookTitle">Book Name : </label>&nbsp;
		<input type="text" name="bTitle" id="name" placeholder="Enter the book title" required>
		<br><br>

		<label for="authorName">Author : </label> <br>
		<input type="text" name="bAuthor" id="name" placeholder="Enter author name" required>
		<br><br>

		<label for="catagory">Catagory : </label> <br>
		<select name="bCatagory" id="name" required>
			<option value="Automata Theory">Theory Of Computer Science (TOC)</option>
			<option value="Software Engineering">Software Engineering</option>
			<option value="Operating System">Operating System</option>
			<option value="Multimedia">Multimedia</option>
			<option value="Programming Language">Programming Language</option>
			<option value="Data Structure">Data Structure</option>
			<option value="Digital Circuit">Digital Circuit</option>
			<option value="Computer Organization & Architecture">Computer Organization & Architecture</option>
			<option value="Networking">Networking</option>
			<option value="Digital Image Processing">Digital Image Processing</option>
			<option value="Database Management System">Database Management System</option>
			<option value="Graphics">Graphics</option>
		</select> <br><br>

		<label for="publishers">Publishers : </label> <br>
		<input type="text" name="bPublishers" id="name" placeholder="Enter publisher's name" required> 
		<br><br>

		<label for="edition">Edition : </label> <br>
		<input type="text" name="bEdition" id="name" placeholder="Enter edition" required> <br><br>

		<label for="language">Language : </label>&nbsp;
		<select name="bLanguage" id="name" required>
			<option value="English">English</option>
		</select> <br><br>

		<label for="binding">Binding : </label> <br>
		<select name="bookBinding" id="name" required>
			<option value="Paper cover">Paperback</option>
			<option value="Hard cover">Hardcover</option>
		</select> <br><br>

		<label for="price">Price : </label> <br>
		<input type="number" name="bPrice" id="name" placeholder="Enter book price" required> <br><br>

		<label for="pages">Number of pages : </label> <br>
		<input type="number" name="bPages" id="name" placeholder="Enter total number of pages" required> 
		<br><br>

		<label for="noOfCopies">No of copies : </label> <br>
		<input type="number" name="noOfCopies" id="name" placeholder="Enter number of copies" required> 
		<br><br>

		<label for="creationDate">Date : </label> <br> 
		<input type="text" name="creationDate" id="name" value="<?php echo Date('Y-m-d') ?>" readonly required> <br><br> 

		<label for="status">Status : </label>&nbsp;&nbsp;&nbsp;
		Active&nbsp;<input type="radio" name="status" value="Active"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Inactive&nbsp;<input type="radio" name="status" value="Inactive">
		<br><br>

		<div class="submitButton">
		<input type="submit" value="Add" name="addbook" id="submit">
		<br><br>
		</div>

		</form>
	</div>
	</div>

</body>
</html>