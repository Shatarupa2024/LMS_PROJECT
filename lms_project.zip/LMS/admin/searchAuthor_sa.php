<!-- PHP code for connection -->

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
    
   if(isset($_POST['searchAuthors'])){

        @$auother = $_POST["bAuthor"];

        $query = "SELECT DISTINCT AUTHOR_NAME FROM booklist WHERE AUTHOR_NAME = '$auother'";
        $result = mysqli_query($conn, $query);
    }
?>

<!-- HTML page -->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="viewListedBook.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <h2 align="center"><u>List Of Authors</u></h2><br>
        <table  id = "table" align="center">
            <?php
            if(mysqli_num_rows($result)>0){
                while($rows = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <th>Author Name</th>
                <th>Creation Date</th>
                <th>Modification Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <tr>
            <!--fetch catagory from booklist-->
            <td><?php echo $rows['AUTHOR_NAME'];?></td>

            <!--fetch creation date of catagory-->
            <?php 
                $auth = $rows['AUTHOR_NAME'];
                $cDate = mysqli_query($conn, "SELECT CREATION_DATE FROM booklist WHERE AUTHOR_NAME = '$auth'");
                $data1 = mysqli_fetch_assoc($cDate);
                //echo $data;
            ?>
            <td><?php echo $data1['CREATION_DATE'];?></td>

            <!--fetch modification date of catagory-->
            <?php
                $auth = $rows['AUTHOR_NAME'];
                $mDate = mysqli_query($conn, "SELECT MODIFICATION_DATE FROM booklist WHERE AUTHOR_NAME = '$auth' ORDER BY ISBN_NO DESC");
                $data2 = mysqli_fetch_assoc($mDate);
                //echo $data;
            ?>
            <td><?php echo $data2['MODIFICATION_DATE'];?></td>

            <!--fetch status of catagory-->
            <?php
                $auth = $rows['AUTHOR_NAME'];
                $status = mysqli_query($conn,"SELECT STATUS FROM booklist WHERE AUTHOR_NAME='$auth'");
                //$data3 = mysqli_fetch_assoc($status);
                //echo var_dump($data3);
                $f = 0;
                while($data3 = mysqli_fetch_assoc($status)) {
                    if($data3['STATUS'] == "Active") {
                        $f++;
                    }
                }
                if($f == 0) {
                    $Status = "Inactive";
                } else {
                    $Status = "Active";
                }
            ?>
            <td><?php echo $Status;?></td>

            <form action="viewListedAuthorsBooks_sh.php" method="POST">
                <input type="hidden" name="auth" value="<?php echo $auth ?>">
                <td><input type="submit" name="viewBook" class="btn btn-success" value="View Books"></td>
            </form>

        </tr>
        <?php
            }
        } 
        else{
            echo '<script> alert("Data not found!"); history.go(-1);</script>';
        }
        ?>
        </table><br><br>
        <form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
    </div>
</body>
</html>