<!-- PHP code for connection -->

<?php
session_start();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }


if(isset($_POST['edit'])){


        @$admin_id = $_POST['admin_id'];

        @$n = $_POST['fname'].' '.$_POST['lname'];
        $name = strtoupper($n);
        $admin_name = $name;
            
        @$email = $_POST['email'];
        @$phone = $_POST['phnumber'];
        @$password = $_POST['password'];
        @$modification_date = $_POST["modification_date"];
        
        $query = "SELECT * FROM admin_table WHERE ADMIN_ID = '$admin_id'";
        $result = mysqli_query($conn, $query);

        $row = mysqli_fetch_array($result);

        if($row){

            $query2 = "UPDATE admin_table SET ADMIN_NAME = '$admin_name',  ADMIN_EMAIL_ID = '$email', ADMIN_MOBILE_NO = '$phone', ADMIN_PASSWORD = '$password' , ADMIN_MODIFICATION_DATE = '$modification_date' WHERE ADMIN_ID = '$admin_id'";

            $result2 = mysqli_query($conn, $query2);
            echo '<script> alert("Data Updated"); </script>';
        }
        else{
            echo '<script> alert("Data not updated"); </script>';
        }
    }

?>


<!-- HTML page -->

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="adminDashboardStyle_sh.css">
<link rel="stylesheet" type="text/css" href="changePasswd.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
    <ul>
            <li><a href="adminDashboard_sh.php"><i class="fa fa-th-large"></i> Dashboard</a></li>
            <li><a href="manageBook.php"><i class="fas fa-book-medical"></i> Manage Books</a></li>
            <li><a href="adminIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="memberSection.php"><i class="fa fa-group"></i> Members</a></li>
            <li><a href="adminSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="adminLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="main">
            <div class="register">
            <form method="post">

            <label>Admin Id : </label><br>
            <input type="text" name="admin_id" id="id" value="<?php echo $_SESSION['adminId'] ?>" readonly><br><br>

            <label>Name : </label><br>
            <input type="text" name="fname" id="name" value="<?php echo $_SESSION['adminName'] ?>" required ><br><br>

            <label>Email Id : </label><br>
            <input type="email" name="email" id="email" value="<?php echo $_SESSION['adminEmail'] ?>" required><br><br>

            <label>Contact Number : </label><br>
            <input type="number" name="phnumber" id="number" value="<?php echo $_SESSION['adminPh'] ?>" required><br><br>

            <label>Password : </label><br>
            <input type="password" name="password" id="password" value="<?php echo $_SESSION['adminPasswd'] ?>" required ><br><br>

            <label>Date : </label> <br> 
            <input type="text" name="modification_date" id="name" value="<?php echo Date('Y-m-d    H:i:s') ?>" readonly required> <br><br> 


            <div class="submit-btn">
            <input type="submit" name="edit" id="submit" value="UPDATE DATA">
            </div>

        </form>
    </div>
    </div><br>
<h3><b><a href="adminSettings.php" style="margin-left: 20px;">Go to previous page</a></b></h3><br><br></div>
</body>
</html>

<?php
mysqli_close($conn);
?>
