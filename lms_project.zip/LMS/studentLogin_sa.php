<html>
<head>
  <link rel="stylesheet" href="homepageStyles1.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<body>

  <center>
    <h1 style="font-family: georgia; font-size: 30px; font-weight: bold; color: #09080f;"><u><i> Online Library Management System </i></u></h1>
  </center> 
  <hr>

<div class="marq">
  <marquee behavior="alternate" direction="right">Bijoy Krishna Girls' College , Howrah
  <br>
  &nbsp; &nbsp; &nbsp;Computer Science Department</marquee>
</div>
  <hr>

  <ul>
    <a href="homePage.php"><i class="fa fa-home fa-2x" style="color: black; margin-top:9px;"></i></a>
    <li><a href="terms&conditions.php"><i> Student Register </i></a></li>
    <li><a href="studentLogin_sa.php"><i> Student Login </i></a></li>
    <li><a href="adminRegistration_sa.php"><i> Admin Register </i></a></li>
    <li><a href="adminLogin_sa.php"><i> Admin Login </i></a></li>
  </ul>

</body>
</html>



<!-- PHP code for connection -->
 <?php
session_start();

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lmsdb";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<?php

/* Taking values from the student_table */

  if(isset($_POST['login'])) {

      $conn = mysqli_connect($servername, $username, $password, $dbname);
      if($_SERVER["REQUEST_METHOD"] == "POST"){

          @$student_roll = $_POST['student_clgRoll'];

          @$n = $_POST['fname'].' '.$_POST['lname'];
          @$name = strtoupper($n);
          @$stu_name = $name;

          @$batch = $_POST['batch'];
          @$semester = $_POST['semester'];
          @$reg_number = $_POST['regnumber'];
          @$phone = $_POST['phnumber'];
          @$email = $_POST['email'];
          @$password = $_POST['password']; 
          @$joining_date = $_POST["joining_date"];
          @$modification_date = $_POST["joining_date"];

          $query = "SELECT * FROM student_list WHERE  STD_ID = '$student_roll' && STD_PASSWORD = '$password'";
          $result = mysqli_query($conn, $query);

          $row = mysqli_fetch_array($result , MYSQLI_ASSOC);

          $count = mysqli_num_rows($result);

          if($count == 1){
            echo '<script> alert("Login Sucessfull.."); </script>';
            echo '<script>window.location = "student/welcomeStudentPage.php";</script>';
            
            $student_roll = $row['STD_ID'];
            $_SESSION['student_id'] = $student_roll;

            $stu_name = $row['STD_NAME'];
            $_SESSION['student_name'] = $stu_name;

            $batch = $row['STD_BATCH'];
            $_SESSION['student_batch'] = $batch;

            $semester = $row['STD_SEMESTER'];
            $_SESSION['student_sem'] = $semester;

            $reg_number = $row['STD_REG_NO'];
            $_SESSION['student_reg'] = $reg_number;

            $phone = $row['STD_CONTACT_NO'];
            $_SESSION['student_ph'] = $phone;

            $email = $row['STD_EMAIL'];
            $_SESSION['student_email'] = $email;

            $password = $row['STD_PASSWORD'];
            $_SESSION['student_passwd'] = $password;

            $joining_date = $row['STD_JOINING_DATE'];
            $_SESSION['student_jDate'] = $joining_date;

            $modification_date = $row['STD_MODIFICATION_DATE'];
            $_SESSION['student_mDate'] = $modification_date;

            //header("location:student/welcomeStudentPage.php");
          }
          else{
            echo '<script> alert("Login failed...Invalid username or password..."); </script>';
            echo '<script>window.location = "studentLogin_sa.php";</script>';
          }

          /*Close the connection.*/
          mysqli_close($conn);
      }
  }

?>


<html>
<head>
<title></title>
<link rel="stylesheet" href="adminStudentLoginStyle_sa.css">
</head>
<body>
<div class="main">
    <form method="post">
    
    <div class="imgcontainer">
      <img src="avatar.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b> Student Roll No. : </b></label><br>
      <input type="text" name="student_clgRoll" id="id" placeholder="Enter your college roll_no" required><br>

      <label><b> Password : </b></label><br>
      <input type="password" name="password" placeholder="Enter Password" required><br>

      <button type="submit" name="login"><b> Login </b></button>
    </div>

      <button type="button" class="cancelbtn"><a href="homePage.php"> Cancel </a></button>

      <span class="psw"><a href="studentForgotPassword_sa.php"><b>Forgot Password ? </b></a></span>

      <span class="psw"> Not register yet ? <a href="studentRegistration_sa.php"><b> Register here </b></a></span>

    </form>
</div>
</body>
</html>