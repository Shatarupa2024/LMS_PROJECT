<!-- PHP code for connection -->

<?php
session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for auto increment the isbn no -->

<?php
	
    $s_id = $_SESSION['student_id']; 
	$sBatch = substr($s_id, 0, 2);
   	$sId = substr($s_id, 6);
	$name = $_SESSION['student_name'];
	$sName = substr($name, 0, 2);
	$iNo = "IS-" . $sBatch . "-". $sId . "-" . $sName . "-";
    $query = "SELECT * FROM issued_book_list WHERE ISSUE_NO LIKE '$iNo%' ORDER BY ISSUE_NO DESC LIMIT 1";
    $result = mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result);
	@$last_issue_no = $row['ISSUE_NO'];
	if ($last_issue_no == "") {
		$issue_no = "IS-" . $sBatch . "-". $sId . "-" . $sName . "-" . "01"; //IS-002-NA-01
	}
	else {
		$no = substr($last_issue_no, 13); //let last_issue_no = IS-19-012-AN-01. so get 01 in string
        $digit = intval($no); //get 01 in integer
        $digit = $digit + 1; //get 01+1 = 2
        $get_string = str_pad($digit, 2, 0, STR_PAD_LEFT); //get 02 in string
        $issue_no = "IS-" . $sBatch . "-". $sId . "-" . $sName . "-" . $get_string; //finally get IS-19-012-AN-02
	}
?>

<!-- PHP code for function issue book -->
<?php

function issueBook($issueNo, $isbnNo, $sId, $iDate, $rDate) {
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
	$sql = "INSERT INTO issued_book_list VALUES ('$issueNo', '$isbnNo', '$sId', '$iDate', '$rDate', 'True')";
	if (mysqli_query($conn, $sql)) { 
        echo "<script>alert('Successfully issued.'); history.go(-2);</script>";
        //echo "<script>window.location = 'bookSection.php'; </script>";

  	} else {
        echo "<script>alert('Error: ".$sql."\n".mysqli_error($conn)."'); history.go(-2);</script>";
        //echo "<script>window.location = 'bookSection.php'; </script>";
        //echo mysqli_error($conn);
    }

    $sql1 = "UPDATE booklist SET 
            			AVAILABLE_COPY=AVAILABLE_COPY-1 WHERE ISBN_NO='$isbnNo'";

    mysqli_query($conn, $sql1);

    //header("location:bookSection.php");
    //exit();
    mysqli_close($conn);
}


?>

<!-- PHP code for insert data in table  -->

<?php
	
	if(isset($_POST['issue'])) {

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $issueNo = $_POST["issueNo"];
            $isbnNo = $_POST["isbnNo"];
            $sId = $_POST["sId"];
            $iDate = $_POST["iDate"];
            $rDate = $_POST["rDate"];
            $rStatus = "True";
            if (!$conn)
            {
                die("Connection failed: " . mysqli_connect_error());
            }

            $query = "SELECT * FROM booklist WHERE ISBN_NO = '$isbnNo'";

			$result = mysqli_query($conn, $query);

			if(mysqli_num_rows($result) == 0) {
				echo "<script>alert('Book not found!'); history.go(-2);</script>";
				//echo "<script>window.location = 'issueABookByStudent_sh.php'; </script>";
			//echo "Book not found";
			} else {
				$row = mysqli_fetch_assoc($result);

				//echo var_dump($row);

				if($row['STATUS'] == "Inactive" || $row['AVAILABLE_COPY'] == 0) {
					echo "<script>alert('Book not available!'); history.go(-2);</script>";
					//echo "<script>window.location = 'bookSection.php'; </script>";
				} else {
					//check for student aviability
					$query = "SELECT * FROM student_list WHERE STD_ID='$sId'";
					$result = mysqli_query($conn, $query);
					$row = mysqli_fetch_assoc($result);
					if ($row['STD_STATUS'] == "Inactive") {
						echo "<script>alert('Student not available!'); history.go(-2);</script>";
						//echo "<script>window.location = 'bookSection.php'; </script>";
					} else {
						//check this books is already taken by this student or not
						$query = "SELECT * FROM issued_book_list WHERE  ISBN_NO='$isbnNo' AND STD_ID='$sId' ORDER BY ISSUE_NO DESC";

						$result = mysqli_query($conn, $query);

						if(mysqli_num_rows($result) > 0) {
							$row = mysqli_fetch_assoc($result);
							$rStatus = $row['RETURN_STATUS'];

							if($rStatus == "True") {
								echo "<script>alert('This book is already taken by you.'); history.go(-2);</script>";
								//echo "<script>window.location = 'bookSection.php'; </script>";
								
							} else {
								issueBook($issueNo,$isbnNo,$sId,$iDate,$rDate);
							}
						} else {
							issueBook($issueNo,$isbnNo,$sId,$iDate,$rDate);
						}
					}
				}
			}
            mysqli_close($conn);
        }
    }
?>


<!-- HTML page -->

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="formStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
	    	<li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2><u>Issue A Book</u></h2><br>
		<div class="form">
		<form method="POST">
		<label for="book issue no">Issue number : </label>
		<input style="color: blue;" type="text" name="issueNo" id="name" value="<?php echo $issue_no; ?>" readonly required>
		<br><br>

		<label for="student id">Student ID : </label>
		<input type="text" name="sId" id="name" value="<?php  
				//session_start();
				$sId = $_SESSION['student_id'];
				echo $sId;
			?>"
			readonly required>
		<br><br>

		<label for="isbn no">Book ISBN No : </label>
		<input type="text" name="isbnNo" id="name" value="<?php echo $_POST['bIsbn']; ?>" readonly required>
		<br><br>

		<label for="issue date">Issue Date : </label> <br> 
		<input type="date" name="iDate" id="name" value="<?php echo date('Y-m-d')?>" readonly required><br><br> 
		
		<label for="return date">Return Date : </label> <br> 
		<input type="date" name="rDate" id="name" value="<?php
			$today = date('Y-m-d');
			$new = strtotime("+7 day",strtotime($today));
			$rdate = date('Y-m-d', $new);
			echo $rdate; ?>" readonly required><br><br>

		<div class="submitButton">
		<a href="bookSection.php"><input type="submit" value="ISSUE" name="issue" id="submit">
		<br><br>
		</div>
	</div>
	<form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
		</form>
	</div>

</body>
</html>