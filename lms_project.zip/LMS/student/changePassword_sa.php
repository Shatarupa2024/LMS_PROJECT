<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }

if(isset($_POST['changePassword'])) {
    @$student_roll = $_POST['student_clgRoll'];
	@$old_Passwd = $_POST['old_password'];
	@$new_Passwd = $_POST['new_password'];
    @$modification_date = $_POST["modification_date"];

	$query = "SELECT STD_PASSWORD FROM student_list WHERE STD_PASSWORD = '$old_Passwd'";
	$result = mysqli_query($conn, $query);

	$rows = mysqli_fetch_array($result);
    if($rows == 0){
        echo '<script> alert("Old Password Does Not Match"); </script>';
    }	
        if($rows){
    		
    		$query2 = "UPDATE student_list SET STD_PASSWORD ='$new_Passwd' , STD_MODIFICATION_DATE = '$modification_date' WHERE STD_PASSWORD ='$old_Passwd'";
    		$result2 = mysqli_query($conn, $query2);
    		
    		echo '<script> alert("Password Changed Succesfully."); </script>';
    	    echo '<script>window.location = "studentSettings.php"; </script>';
        }
}
?>

<!-- HTML page -->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
   <link rel="stylesheet" type="text/css" href="changePasswd.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
            <li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="main">
            <div class="register">
                <form method="post">

    				<label>Old Password : </label><br>
    				<input type="password" name="old_password" id="password" required><br><br>

    				<label>New Password : </label><br>
    				<input type="password" name="new_password" id="password" required><br><br>

                    <label>Date : </label> <br> 
                    <input type="text" name="modification_date" id="name" value="<?php echo Date('Y-m-d    H:i:s') ?>" readonly required> <br><br> 

                    <div class="submit-btn">
    				<input type="submit" id="submit" name="changePassword" value="Change Password">
                    <br><br>
                    </div>
	           </form>
        </div></div>
<h3><b><a href="studentSettings.php" style="margin-left: 20px;">Go to previous page</a></b></h3>
</div>
</body>
</html>