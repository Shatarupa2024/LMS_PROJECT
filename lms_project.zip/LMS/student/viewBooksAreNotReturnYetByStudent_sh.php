<!-- PHP code for connection -->

<?php
	session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
 	if($conn == false){
    	die("ERROR: Connection failed".mysqli_connect.error());
	}
	$s_id = $_SESSION['student_id']; 
	$sBatch = substr($s_id, 0, 2);
   	$sId = substr($s_id, 6);
	$name = $_SESSION['student_name'];
	$sName = substr($name, 0, 2);
	$iNo = "IS-" . $sBatch . "-". $sId . "-" . $sName . "-";
	$query = "SELECT * FROM issued_book_list WHERE ISSUE_NO LIKE '$iNo%' AND RETURN_STATUS = 'True'";
	$result = mysqli_query($conn, $query);
	//mysqli_close($conn);
?>

<!-- HTML page -->

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
	    	<li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2 align="center"><u>List Of Non-Returned Book</u></h2><br>
		<?php 
			//$result = mysqli_query($conn, "SELECT * FROM issued_book_list WHERE RETURN_STATUS = 'True'");
			if(mysqli_num_rows($result) == 0){
				echo "<script>alert('No books are issued by you.');</script>";
				echo "<script>window.location = 'studentIssueReturnSec.php'; </script>";
			} else {
				

		?>
			<table id = "table" align="center">
            <tr>
                <th>Issue Number</th>
                <th>Student ID</th>
                <th>Book ISBN Number</th>
                <th>Book Title</th>
                <th>Issued Date</th>
                <th>Return Date</th>
                <th>Action</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php 
            while($rows = mysqli_fetch_assoc($result)){
            ?>
        	<tr>
            <td><?php echo $rows['ISSUE_NO'];?></td>
            <td><?php echo $rows['STD_ID'];?></td>
            <td><?php echo $rows['ISBN_NO'];?></td>
            <?php 
            $isbn = $rows['ISBN_NO'];
            $q = "SELECT BOOK_TITLE FROM booklist WHERE ISBN_NO = '$isbn'";
            $rs = mysqli_query($conn, $q);
            $r = mysqli_fetch_assoc($rs);
            ?>
            <td><?php echo $r['BOOK_TITLE']; ?></td>
            <td><?php echo $rows['ISSUED_DATE'];?></td>
            <td><?php echo $rows['RETURN_DATE'];?></td>
            <form action="returnABookFromNonReturnedBookListInStudentSec_sh.php" method="POST">
                <input type="hidden" name="sId" value="<?php echo $rows['STD_ID']; ?> ">
                <input type="hidden" name="issueNo" value="<?php echo $rows['ISSUE_NO']; ?> ">
                <input type="hidden" name="isbnNo" value="<?php echo $rows['ISBN_NO']; ?> ">
                <input type="hidden" name="bTitle" value="<?php echo $r['BOOK_TITLE']; ?> ">
                <td><input type="submit" name="view" class="btn btn-success" value="Return"></td>
            </form>
        	</tr>
        <?php
            	}
        	}
        ?>
        	</table><br>
        	<h4><a href="studentIssueReturnSec.php" style="color: #3a137d; margin-left: 20px;">Back to previous page</a></h4><br><br>
	</div>
</body>
</html>