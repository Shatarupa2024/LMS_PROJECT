<!-- PHP code for connection -->

<?php
session_start();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }


if(isset($_POST['edit'])){

        @$student_roll = $_POST['student_clgRoll'];

        @$n = $_POST['fname'].' '.$_POST['lname'];
        $name = strtoupper($n);
        $stu_name = $name;

        @$batch = $_POST['batch'];
        @$semester = $_POST['semester'];
        @$reg_number = $_POST['regnumber'];
        @$phone = $_POST['phnumber'];
        @$email = $_POST['email'];
        @$password = $_POST['password']; 
        @$modification_date = $_POST["modification_date"];
        
        $query = "SELECT * FROM student_list WHERE STD_ID = '$student_roll'";
        $result = mysqli_query($conn, $query);

        $row = mysqli_fetch_array($result);

        if($row){

            $query2 = "UPDATE student_list  SET STD_NAME = '$stu_name', STD_BATCH = '$batch',  STD_SEMESTER = '$semester', STD_REG_NO = '$reg_number', STD_CONTACT_NO = '$phone', STD_EMAIL = '$email', STD_PASSWORD = '$password' , STD_MODIFICATION_DATE = '$modification_date' WHERE STD_ID = '$student_roll'";

            $result2 = mysqli_query($conn, $query2);
            echo '<script> alert("Data Updated"); </script>';
            echo '<script>window.location = "studentSettings.php";</script>';
        }
        else{
            echo '<script> alert("Data not updated"); </script>';
            echo '<script>window.location = "studentSettings.php";</script>';
        }
    }

?>


<!-- HTML page -->

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
   <link rel="stylesheet" type="text/css" href="changePasswd.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
            <li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="main">
        <div class="register">
        
        <form method="post">
        <label>Student Roll No. : </label><br>
        <input type="text" name="student_clgRoll" id="name" value="<?php echo $_SESSION['student_id'] ?>"><br><br>

        <label>Name : </label><br>
        <input type="text" name="fname" id="name" value="<?php echo $_SESSION['student_name'] ?>"><br><br>

        <label>Batch : </label><br>
        <select name="batch" id="name" value="<?php echo $_SESSION['student_batch'] ?>">

        <?php
            if($_SESSION['student_batch'] == $_POST['batch']) {
                echo "<option value='" . $_SESSION['student_batch'] ."' selected>" . $_SESSION['student_batch'] . "</option>";
            }
            else{
                echo "<option value='" . $_SESSION['student_batch'] ."'>" . $_SESSION['student_batch'] . "</option>";
            }
        ?>
            <option value="2017-2020">2017-2020</option>
            <option value="2018-2021">2018-2021</option>
            <option value="2019-2022">2019-2022</option>
            <option value="2020-2023">2020-2023</option>
            <option value="2021-2024">2021-2024</option>
            <option value="2022-2025">2022-2025</option>
        </select><br><br>

        <label>Semester : </label><br>
        <select name="semester" id="name" value="<?php echo $_SESSION['student_sem'] ?>">

        <?php
            if($_SESSION['student_sem'] == $_POST['semester']) {
                echo "<option value='" . $_SESSION['student_sem'] ."' selected>" . $_SESSION['student_sem'] . "</option>";
            }
            else{
                echo "<option value='" . $_SESSION['student_sem'] ."'>" . $_SESSION['student_sem'] . "</option>";
            }
        ?>

            <option value="Semester-1">Semester-1</option>
            <option value="Semester-2">Semester-2</option>
            <option value="Semester-3">Semester-3</option>
            <option value="Semester-4">Semester-4</option>
            <option value="Semester-5">Semester-5</option>
            <option value="Semester-6">Semester-6</option>
        </select><br><br>
        

        <label>Registration Number : </label><br>
        <input type="text" name="regnumber" id="number" value="<?php echo $_SESSION['student_reg'] ?>"><br><br>

        <label>Contact Number : </label><br>
        <input type="text" name="phnumber" id="number" value="<?php echo $_SESSION['student_ph'] ?>"><br><br>

        <label>Email id : </label><br>
        <input type="email" name="email" id="email" value="<?php echo $_SESSION['student_email'] ?>"><br><br>

        <label>Password : </label><br>
        <input type="password" name="password" id="password" value="<?php echo $_SESSION['student_passwd'] ?>"><br><br>

        <label>Date : </label> <br> 
        <input type="text" name="modification_date" id="name" value="<?php echo Date('Y-m-d') ?>" readonly required> <br><br> 

        <div class = "submit-btn">
        <input type="submit" value="Update Data" name="edit" id="submit"></div><br>

        </form>
    </div></div>
<h4><b><a href="studentSettings.php" style="margin-left: 20px;">Go to previous page</a></b></h4><br><br>
</div>
</body>
</html>

<?php
mysqli_close($conn);
?>
