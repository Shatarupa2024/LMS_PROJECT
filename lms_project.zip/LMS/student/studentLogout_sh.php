<?php 
session_start();
unset($_SESSION['student_name']);
unset($_SESSION['password']);
session_destroy();
header("location: ../homePage.php");
?>