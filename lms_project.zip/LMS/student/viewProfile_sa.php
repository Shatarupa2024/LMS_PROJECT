<!-- PHP code for connection -->
<?php
session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }

    $student_roll = $_SESSION['student_id'];

    $query = "SELECT * FROM student_list WHERE STD_ID = '$student_roll'";
    $result = mysqli_query($conn, $query);
?>

<!-- HTML page -->

<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
   <link rel="stylesheet" type="text/css" href="tableStyle2_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
            <li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <br><br>
        <table id = "table" align="center" cellspacing="0" cellpadding="0">
            <?php
                while($row = mysqli_fetch_array($result))
                {
            ?>
            <tr>
                <td>College Roll No.</td>
                <td><?php echo $row['STD_ID'];?></td>
                <td> </td>
                <td>Name</td>
                <td><?php echo $row['STD_NAME'];?></td>
            </tr>
            <tr>
                <td>Batch</td>
                <td><?php echo $row['STD_BATCH'];?></td>
                <td> </td>
                <td>Semester</td>
                <td><?php echo $row['STD_SEMESTER'];?></td>
            </tr>
            <tr>
                <td>Registration Number</td>
                <td><?php echo $row['STD_REG_NO'];?></td>
                <td> </td>
                <td>Contact number</td>
                <td><?php echo $row['STD_CONTACT_NO'];?></td>
            </tr>
            <tr>
                <td>Email Id</td>
                <td><?php echo $row['STD_EMAIL'];?></td>
                <td> </td>
                <td>Joining Date</td>
                <td><?php echo $row['STD_JOINING_DATE'];?></td>
            </tr>
            <tr>
                <td>Modification Date</td>
                <td><?php echo $row['STD_MODIFICATION_DATE'];?></td>
            </tr>
            <?php
                }
            ?>
            <tr>
                <td></td><td></td><td> <a href="studentSettings.php" style="color: #3a137d;">Back to Previous Page</a> </td><td></td><td></td>
            </tr>
        </table>
   </div>
</body>
</html>
<?php
mysqli_close($conn);
?>
