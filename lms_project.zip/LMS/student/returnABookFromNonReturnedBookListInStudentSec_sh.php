<!-- PHP code for connection -->

<?php
session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>


<!-- HTML page -->

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="formStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
	    	<li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<div class="container">
		<h2><u>Return A Book</u></h2><br>
		<div class="form">
		<form method="POST">
		<label for="student id">Student Roll Number : </label>
		<input type="text" name="issueNo" id="name" value="<?php echo $_POST['sId']; ?>" readonly required><br><br>
        <label for="book issue no">Issue number : </label>
		<input type="text" name="issueNo" id="name" value="<?php echo $_POST['issueNo']; ?>" readonly required>
		<br><br>
		<label for="isbn no">Book ISBN No : </label>
		<input type="text" name="isbnNo" id="name" value="<?php echo $_POST['isbnNo']; ?>"  readonly required>
		<br><br>
		<label for="book title">Book Title : </label>
		<input type="text" name="bTitle" id="name" value="<?php echo $_POST['bTitle']; ?>"  readonly required>
		<br><br>
		<label for="return date">Return Date : </label> <br> 
		<input type="date" name="rDate" id="name" value="<?php echo date('Y-m-d')?>" readonly required><br><br> 
		<label for="fine">Fine : </label> <br> 
		<?php

		$iNo = $_POST['issueNo'];
		$res = mysqli_query($conn, "SELECT RETURN_DATE FROM ISSUED_BOOK_LIST WHERE ISSUE_NO='$iNo'");
		$row = mysqli_fetch_array($res);
		$date1 = strtotime(date('Y-m-d'));
		$date2 = strtotime($row['RETURN_DATE']);
		//Get the difference and divide into total no. seconds 60/60/24 to get number of days
		$days = ($date1 - $date2)/60/60/24 ;
		if ($days == 0 | $days < 0) {
			$fine = "Fine Not Generated";
		} else {
			$days = doubleval($days);
			$fine = doubleval($days * 2);
			$fine = strval($fine);
		}
		if($fine == "Fine Not Generated") {
		?>
			<input type="text" name="fine" id = "name" value = "<?php echo $fine; ?>" readonly required>
			<br><br>
			<div class="submitButton">
			<button type="submit" id="submit" formaction="storeFineNa_sh.php" mathod="POST">Submit</button></div>

		<?php 

		}	else {

		?>
			<input type="text" name="fine" id = "name" value = "<?php echo $fine; ?>" readonly required>
			<br><br>
			<div class="submitButton">
			<button type="submit" id="submit" formaction="storeFine_sh.php" mathod="POST">Go To Next Page</button></div>

		<?php 
		} ?>
		
		</div>
		<form><input type="button" value="Go to previous page" onClick="history.go(-1);" style="border: none; border-radius: 2px ; padding: 5px; outline: none; color: darkslateblue; font-size: 17px; font-weight: bold; background-color: white; margin-left: 20px;"></form><br><br>
	</form>
	</div>
</body>
</html>