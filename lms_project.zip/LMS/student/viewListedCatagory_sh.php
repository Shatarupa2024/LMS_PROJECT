<!-- PHP code for connection -->

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lmsdb";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if($conn == false){
        die("ERROR: Connection failed".mysqli_connect.error());
    }
    
   // mysqli_close($conn);
?>

<!-- HTML page -->

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="tableStyle_sh.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="side-menu">
        <div class="AdminPanel">
            <h1>Sections</h1>
        </div>
        <ul>
            <li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
            <li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
            <li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
            <li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
        </ul>
    </div>
    <div class="container">
        <?php 
            $result = mysqli_query($conn, "SELECT * FROM booklist");
            if(mysqli_num_rows($result) == 0){
                echo "<h1 style='color: green; text-align: center;'>Book list is empty.</h3><br><br>";
                echo "<h4><a href='adminIssueBook.php' style='color: #20064c;'>Back to previous page</a></h4>";
            } else {      

        ?>
        <h2 align="center"><u>List Of Catagories</u></h2><br>
        <div class="search">
            <form action="searchCatagory_sa.php" method="post">
                <input type="text" name="bCatagory" placeholder="      Search... ">
                <button type="submit" name="searchCatagory">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>
        <table  id = "table" align="center">
            <tr>
                <th>Catagory</th>
                <th>Creation Date</th>
                <th>Modification Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
        <?php
            $query = "SELECT DISTINCT CATAGORY FROM booklist";
            $result = mysqli_query($conn, $query);
            while($rows = mysqli_fetch_assoc($result))
            {
        ?>
        <tr>
            <!--fetch catagory from booklist-->
            <td><?php echo $rows['CATAGORY'];?></td>

            <!--fetch creation date of catagory-->
            <?php 
                $cat = $rows['CATAGORY'];
                $cDate = mysqli_query($conn, "SELECT CREATION_DATE FROM booklist WHERE CATAGORY='$cat'");
                $data1 = mysqli_fetch_assoc($cDate);
                //echo $data;
            ?>
            <td><?php echo $data1['CREATION_DATE'];?></td>

            <!--fetch modification date of catagory-->
            <?php
                $cat = $rows['CATAGORY'];
                $mDate = mysqli_query($conn, "SELECT MODIFICATION_DATE FROM booklist WHERE CATAGORY = '$cat' ORDER BY ISBN_NO DESC");
                $data2 = mysqli_fetch_assoc($mDate);
                //echo $data;
            ?>
            <td><?php echo $data2['MODIFICATION_DATE'];?></td>

            <!--fetch status of catagory-->
            <?php
                $cat = $rows['CATAGORY'];
                $status = mysqli_query($conn, "SELECT STATUS FROM booklist WHERE CATAGORY='$cat'");
                //$data3 = mysqli_fetch_assoc($status);
                //echo var_dump($data3);
                $f = 0;
                while($data3 = mysqli_fetch_assoc($status)) {
                    if($data3['STATUS'] == "Active") {
                        $f++;
                    }
                }
                if($f == 0) {
                    $Status = "Inactive";
                } else {
                    $Status = "Active";
                }
            ?>
            <td><?php echo $Status;?></td>

            <form action="viewListedCatagoriesBooks_sh.php" method="POST">
                <input type="hidden" name="cat" value="<?php echo $cat ?>">
                <td><input type="submit" name="viewBook" class="btn btn-success" value="View Books"></td>
            </form>

        </tr>
        <?php
            } //end while loop
        } //end of else part
        ?>
        </table><br><br>
        <h4><a href="bookSection.php" style="color: #3a137d; margin-left: 30px;">Back to previous page</a></h4><br><br>
    </div>
</body>
</html>