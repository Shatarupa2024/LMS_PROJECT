<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Section</title>
	<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	   	<ul>
	    	<li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
	    	<li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>	<div class="container">
		<div class="header">
			<br><h2>Library Manegment System | Book Section</h2>
		</div>
		<!--<div class="search">
            <form action="#">
                <input type="text" placeholder=" Search... " name="search">
    			<button>
                    <i class="fa fa-search"></i>
            	</button>
            </form>
        </div>-->
		<div class="content">
			<div class="cards">
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewListedBook_sa.php"><i class="fa fa-book fa-4x" style="color: rgb(92,73,115);"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT * FROM booklist");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewListedBook_sa.php"><h3>Book List</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewListedAuthor_sh.php"><i class="fa fa-users fa-4x" style="color: rgb(92,73,115);"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT DISTINCT AUTHOR_NAME FROM booklist");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewListedAuthor_sh.php"><h3>Author List</h3></a>
					</div>
				</div>
				<div class="card">
					<div class="box">
						<div class="center">
							<a href="viewListedCatagory_sh.php"><i class="far fa-file-alt fa-4x"  style="color: rgb(92,73,115);"></i></a>
						</div>
						<?php
						$res = mysqli_query($conn, "SELECT DISTINCT CATAGORY FROM booklist");
						$row = mysqli_num_rows($res); 
						echo "<h4 style='color: whitesmoke; text-align: center;'>".$row."</h4>";
						?>
						<a href="viewListedCatagory_sh.php"><h3>Catagory List</h3></a>
					</div>
				</div>				
			</div>
		</div>
	</div>
</body>
</html>