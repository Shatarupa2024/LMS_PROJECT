
<!-- PHP code for connection -->

<?php
session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for store the value -->

<?php

	$issueNo = $_POST['issueNo'];
	$rDate = $_POST['rDate'];
	$fine = $_POST['fine'];
	$fineStatus = "NOT CLEARED";

	$query = "SELECT * FROM return_book_list WHERE ISSUE_NO = '$issueNo'";
	$result = mysqli_query($conn, $query);

	if(mysqli_num_rows($result) == 0){
		$q = "INSERT INTO return_book_list VALUES ('$issueNo', '$rDate', '$fine', '$fineStatus')";
		mysqli_query($conn, $q);
		echo "<script>alert('Contact with admin to clear fine.'); history.go(-2); </script>";
		
	} else{
		$q = "UPDATE return_book_list SET 
				RETURN_DATE = '$rDate',
				FINE = '$fine',
				FINE_STATUS = '$fineStatus' WHERE ISSUE_NO = '$issueNo'";
		mysqli_query($conn, $q);
		echo "<script>alert('Contact with admin to clear fine.'); history.go(-2);</script>";
		
	}

	/*$q = "INSERT INTO return_book_list VALUES ('$issueNo', '$rDate', '$fine', '$fineStatus')";

	if (mysqli_query($conn, $q)) {
		echo "<script>alert('Contact with admin to clear fine.');</script>";
		echo "<script>window.location = 'studentReturnBook.php'; </script>";
	} else {
		echo mysqli_error($conn);
	}*/

?>

<!-- HTML code -->

<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="studentDashboardStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="formStyle_sh.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="side-menu">
		<div class="AdminPanel">
			<h1>Sections</h1>
		</div>
	    <ul>
	    	<li><a href="bookSection.php"><i class="fas fa-book"></i> Book Section</a></li>
	    	<li><a href="studentIssueReturnSec.php"><i class="fas fa-book-open"></i> Issue & Return</a></li>
	    	<li><a href="studentSettings.php"><i class="fa fa-gears"></i> Settings</a></li>
	    	<li><a href="studentLogout_sh.php"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
	    </ul>
	</div>
	<!--<div class="container">
		<h3>Contact with admin</h3>

	</div>-->
</div>
</body>
</html>
			