<html>
<head>
  <link rel="stylesheet" href="homepageStyles1.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

  <center>
    <h1 style="font-family: georgia; font-size: 30px; font-weight: bold; color: #09080f;"><u><i> Online Library Management System </i></u></h1>
  </center> 
  <hr>

<div class="marq">
  <marquee behavior="alternate" direction="right">Bijoy Krishna Girls' College , Howrah
  <br>
  &nbsp; &nbsp; &nbsp;Computer Science Department</marquee>
</div>
  <hr>

  <ul>
    <a href="homePage.php"><i class="fa fa-home fa-2x" style="color: black; margin-top:9px;"></i></a>
    <li><a href="terms&conditions.php"><i> Student Register </i></a></li>
    <li><a href="studentLogin_sa.php"><i> Student Login </i></a></li>
    <li><a href="adminRegistration_sa.php"><i> Admin Register </i></a></li>
    <li><a href="adminLogin_sa.php"><i> Admin Login </i></a></li>
  </ul>

</body>
</html>


<!-- PHP code for connection -->
<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lmsdb";
 	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!-- PHP code for auto increment the isbn no -->

<?php
	$query = "SELECT * FROM admin_table ORDER BY ADMIN_ID DESC LIMIT 1";
    $result = mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result);
	@$last_admin_id = $row['ADMIN_ID'];
	if ($last_admin_id == "") {
		$admin_id = "AD01";
	}
	else {
		$num = substr($last_admin_id, 2); //then num = 0001
		$digit = intval($num); //convert string 0001 to integer
		$digit = $digit + 1; // 0001 + 1 = 2 but want 0002 so,
		$get_string = str_pad($digit, 2, 0, STR_PAD_LEFT); // get 0002 as string type 
		$admin_id = "AD" . $get_string;
	}
?>


<!-- PHP code for insert data in table  -->
<?php

	if(isset($_POST['submit'])) {

	    $conn = mysqli_connect($servername, $username, $password, $dbname);
		if($_SERVER["REQUEST_METHOD"] == "POST"){
		
			$admin_id = $_POST['admin_id'];

			$n = $_POST['fname'].' '.$_POST['lname'];
			$name = strtoupper($n);
			$admin_name = $name;
			
		    $email = $_POST['email'];
		    $phone = $_POST['phnumber'];
		    $password = $_POST['password'];
		    $joining_date = $_POST["joining_date"];
		    $modification_date = $_POST["joining_date"];
		    $status = "Active";

			if (!$conn)
	            {
	                die("Connection failed: " . mysqli_connect_error());
	            }

	            $reg = "INSERT INTO admin_table VALUES ('$admin_id' , '$admin_name' ,  '$email' , '$phone' , '$password' , '$joining_date' , '$modification_date' , '$status')";

	            if (mysqli_query($conn, $reg)) {
	               echo '<script> alert("Registration Successfull..."); </script>';
	               echo '<script>window.location = "homePage.php";</script>';
	            } 
	            else {
	                echo '<script> alert("Unsuccessfull...".mysqli_error($conn)); </script>';
	                echo '<script>window.location = "adminRegistration_sa.php";</script>';
	            }
	            mysqli_close($conn);
	        }
	    }
?>



<!-- HTML page -->
<html>
<head>
	<link rel="stylesheet" href="adminStudentRegistrationStyle_sa.css">
</head>
<body>
	<div class="main">
	<div class="register">

	<h2 style="color: purple; font-size: 20px;"><u>Register Here</u></h2>

	<form method="post">

		<label><b> Admin Id : </b></label><br>
		<input type="text" name="admin_id" id="number" placeholder="Enter your id" value="<?php echo $admin_id; ?>" readonly required><br><br>

		<label><b> First Name : </b></label><br>
		<input type="text" name="fname" id="name" placeholder="Enter your first name" required><br><br>

		<label><b> Last Name : </b></label><br>
		<input type="text" name="lname" id="name" placeholder="Enter your Last name" required><br><br>

		<label><b> Email Id : </b></label><br>
		<input type="email" name="email" id="email" placeholder="Enter your valid email-id" required pattern="[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9-]+.[a-z]{2,4}" title="Invalid Email"><br><br>

		<label><b> Contact Number : </b></label><br>
		<input type="text" name="phnumber" id="number"  minlength="10" maxlength="10" placeholder="Enter your contact number" pattern="[6789][0-9]{9}" required><br><br>

		<label><b> Password : </b></label><br>
	    <input type="password" placeholder="Enter the Password" name="password" id='password' required><br><br>


	   	<label><b> Date : </b></label> <br> 
		<input type="text" name="joining_date" id="name" value="<?php echo Date('Y-m-d') ?>" readonly required> <br><br> 

		<div class = "submit-btn">
		<input type="submit" value="Submit" name="submit" id="submit"></div><br>

		<span class="psw" style="font-family: georgia;"> Already registered ? <a href="adminLogin_sa.php"> Log in </a></span>
	</form>
</div>
</div>
</body>
</html>