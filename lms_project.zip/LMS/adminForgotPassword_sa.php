<!-- PHP code for connection -->
<?php
session_start();

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lmsdb";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>


<!-- PHP code for insert data in table  -->
<?php
  if(isset($_POST['show'])) {

      if($_SERVER["REQUEST_METHOD"] == "POST"){
          
        @$email = $_POST['email'];
        @$phone = $_POST['phnumber'];
        @$password = $_POST['password'];

        @$password = $row["ADMIN_PASSWORD"];
        $_SESSION['adminPasswd'] = $password;

          $query = "SELECT ADMIN_PASSWORD,ADMIN_EMAIL_ID,ADMIN_MOBILE_NO FROM admin_table WHERE ADMIN_EMAIL_ID = '$email' AND ADMIN_MOBILE_NO = '$phone'";

          $result = mysqli_query($conn, $query);

          $row = mysqli_fetch_array($result);

          if($row["ADMIN_EMAIL_ID"]== $email && $row["ADMIN_MOBILE_NO"]== $phone){

          $pass = $row["ADMIN_PASSWORD"];
          
          echo '<script> alert("Your Password is : \n'.$pass.'"); </script>';
          echo '<script>window.location = "adminLogin_sa.php";</script>'; 
        }

      else{
            echo '<script> alert("Email-ID or Contact Number Does Not Match !!"); </script>';
            echo '<script>window.location = "adminForgotPassword_sa.php";</script>';
      }

          /*Close the connection.*/
          mysqli_close($conn);
  }
}
?>


<html>
<head>
<title>Forgot Password</title>
<link rel="stylesheet" href="adminStudentLoginStyle_sa.css">
</head>
<body>
<div class="main">
    <form method="post" style="height: 320px;">
      <div class="container">

        <label><b>Email-ID : </b></label><br>
        <input type="email" name="email" id="email" placeholder="Enter your email-id" required><br><br>

        <label><b>Contact Number : </b></label><br>
        <input type="text" name="phnumber" id='number' placeholder="Enter your contact number" required><br>

        <button type="submit" name="show" value="Show Password"><b style="font-size: 16px;"> Show Password </b></button> 
        <center><button type="button" class="cancelbtn"><a href="adminLogin_sa.php"><b> Back to Login Form </b></a></button> </center>

      </div>
    </form>
</div>
</body>
</html>